function st1(game,slot){

	slot.main_menu = function(game,slot){}
	slot.main_menu.prototype = {

		    create: function(game){

		    	//1.6 : 0.625

		    	//ADD COMPONENTS
		    	var self = this;

		    	this.time.advancedTiming = true;
		    	this.stage.backgroundColor = '#202020';
		    	this.stage.disableVisibilityChange = true;
			    this.game.stage.smoothed = false;
			    this.input.maxPointers = 1;
			    //this.game.canvas.style['display'] = 'none';
			    
			    this.scale.pageAlignHorizontally = true;
			    this.scale.pageAlignVertically = true;

				//game.scale.setUserScale(0.7, 0.75);
				game.renderer.renderSession.roundPixels = true; 
				Phaser.Canvas.setImageRenderingCrisp(this.game.canvas) 
				Phaser.Canvas.setSmoothingEnabled(gamex.context, false);

			    slot.master_container = new Sprite()
			    this.add.existing(slot.master_container);
			    //slot.gw == 800 ? slot.master_container.scale.setTo(0.625,0.625) : 0

			    slot.slot_game_holder = new Sprite()
			    slot.master_container.addChild(slot.slot_game_holder)

			    slot.bg = new Pic(1280*0.5,720*0.5-100,"bg2");
		        slot.slot_game_holder.addChild(slot.bg)
		        slot.bg.pivot.setTo(0.5,0.5)
		        slot.bg.smoothed = false
		        //slot.bg.alpha = 0.1

		        slot.machine = new Slot_machine(640,130,slot)
		    	slot.machine.smoothed = false
		    	slot.machine.scale.setTo(0.84,0.84)
		    	slot.slot_game_holder.addChild(slot.machine)

		    	slot.lower_bar = new Slot_lower_bar(0,514,slot)
		    	slot.lower_bar.smoothed = true
		    	slot.lower_bar.char1.x = 160
		    	slot.slot_game_holder.addChild(slot.lower_bar)

		    	slot.lower_bar.update_bet_and_line(slot.be.BET,slot.be.N);

		    	slot.controls = new Slot_controls(1140,280,slot)
		    	slot.slot_game_holder.addChild(slot.controls)
		    	
		    	slot.upper_bar = new Slot_upper_bar(0,20,slot)
		    	slot.slot_game_holder.addChild(slot.upper_bar)
		    	slot.upper_bar.visible = true

		    	slot.menu = new Slot_menu(0,0,slot)
		    	slot.master_container.addChild(slot.menu)
		    	slot.menu.close_btn.input.priorityID = 10
		    	slot.menu.input.priorityID = 10
		    	slot.menu.consumePointerEvent = true
		    	
				/*
		    	var sample = new GameSpriteNoServ2(gamex,this);
				sample.generateMockData();
				slot.master_container.addChild(sample);
				sample.animateIn();
				*/
				
		    	//settings
		    	
		    	slot.menu.visible = false

		    	slot.lower_bar.credit_bar.textf.text.setText(NumCom(slot.be.C))

		    	if(slot.mobile == false){
		    			game.scale.setGameSize(slot.gw, slot.gh == 350 ? 450 : 720)
		    			slot.upper_bar.btn_full_screen.visible = false
		    			slot.machine.x = 640
		    			slot.machine.y = 170;
		    			slot.lower_bar.y = 680
		    			slot.bg.y = (720*0.5) 
		    			slot.lower_bar.char1.x = 110
		    			slot.lower_bar.char1.y = -300
		    			slot.controls.y = 360
		    			slot.controls.x = 1190
		    			slot.full_screen = true
		    			slot.machine.scale.setTo(1,1)
		    			game.scale.refresh()
		    	}

		    	if(slot.be.numFR==1){
	                slot.machine.change_screen("free");
	                slot.auto_spin_mode = true 
	                slot.auto_spin_num = slot.be.free_spin_num - slot.be.curFR
	                slot.controls.update_auto_text();
	                slot.controls.auto_btn.inputEnabled = false
              	}

		    	//CONTROLS
		    	Tap(slot.upper_bar.btn_full_screen,function(){
		    		slot.goFullScreen();
		    	})

		    	//
				Tap(slot.upper_bar.btn_menu,function(){
	    			slot.menu.visible = true
	    			slot.slot_game_holder.visible = false
		    	})

				//
		    	Tap(slot.menu.close_btn,function(){
		    		slot.menu.visible = false
		    		slot.slot_game_holder.visible = true
		    	})

		    	Tap(slot.lower_bar.bet_holder,function(){
		    		if(slot.auto_spin_mode == false  && slot.machine.spinning == false){
			    		if(slot.lower_bar.slot_bet_slider.y==50){
			    			TweenMax.to(slot.lower_bar.slot_bet_slider,0.25,{y:-380,ease:Back.easeOut})
			    			TweenMax.to(slot.lower_bar.slot_line_slider,0.25,{y:50,ease:Back.easeOut})
			    		}else{
			    			TweenMax.to(slot.lower_bar.slot_bet_slider,0.25,{y:50,ease:Back.easeOut})
			    		}
		    		}
		    	})

		    	Tap(slot.lower_bar.line_holder,function(){
		    		if(slot.auto_spin_mode == false  && slot.machine.spinning == false){
			    		if(slot.lower_bar.slot_line_slider.y==50){
			    			TweenMax.to(slot.lower_bar.slot_line_slider,0.25,{y:-380,ease:Back.easeOut})
			    			TweenMax.to(slot.lower_bar.slot_bet_slider,0.25,{y:50,ease:Back.easeOut})
			    		}else{
			    			TweenMax.to(slot.lower_bar.slot_line_slider,0.25,{y:50,ease:Back.easeOut})
			    		}
			    	}
		    	})

		    	//
		    	Tap(slot.controls.spin_btn,function(o){
		    		o.tint = 0xffffff //pressed
		    		o.scale.setTo(1)
		    		slot.machine.go_spin(slot);
		    		slot.controls.opened ? slot.controls.show_buttons() : 0 ;
		    	},function(o){
		    		if(slot.machine.stat>0){
		    			o.tint = 0x990000//down
		    			o.scale.setTo(0.9)
		    		}
		    	})

		    	//
		    	Tap(slot.controls.auto_btn,function(){
		    		slot.controls.show_buttons();
		    	})

		    	window.onhashchange = function() {
					 slot.upper_bar.btn_full_screen.tint = 0xff0000;
				}

		    	slot.adjust_screen_height = function(tall){
		    		//fullscreen
		    		if(slot.full_screen==false){
		    			game.scale.setGameSize(slot.gw, slot.gh == 350 ? 450 : 720)
		    			slot.machine.x = 640
		    			slot.machine.y = 170;
		    			slot.lower_bar.y = 680
		    			slot.bg.y = (720*0.5) 
		    			slot.lower_bar.char1.x = 110
		    			slot.lower_bar.char1.y = -300
		    			slot.controls.y = 360
		    			slot.controls.x = 1190
		    			slot.full_screen = true
		    			//slot.machine.maskee.height = 535
		    			slot.machine.scale.setTo(1,1)
		    			game.scale.refresh()
		    		}else{
		    			game.scale.setGameSize(slot.gw, slot.gh)
		    			slot.machine.x = 640
		    			slot.machine.y = 130;
		    			slot.lower_bar.y = 512
		    			slot.bg.y = (720*0.5) - 120
		    			slot.lower_bar.char1.x = 160
		    			slot.lower_bar.char1.y = -130
		    			slot.controls.y = 280
		    			slot.controls.x = 1140
		    			slot.full_screen = false
		    			//slot.machine.maskee.height = 535
		    			slot.machine.scale.setTo(0.84,0.84)
		    			game.scale.refresh()
		    		}
		    	}

		    },
		    render: function(){
		    	game.debug.text('✯:'+ game.time.fps + " R:"+ slot.gamer_render, 1050, 14, "#00ff00");
		    	slot.controls.children.forEach(function(sprite) {
		    		game.debug.body(sprite)
		    	})

		    }
	};


	


	

}//~st1



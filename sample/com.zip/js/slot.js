//-------------------------------------------
    var Btn = function _Btn(x,y,img,center,cab){
    	Phaser.Sprite.call(this, gamex, x, y,img);
    	center ? this.anchor.setTo(0.5,0.5) : 0
        this.input = new Phaser.InputHandler(this)
        this.inputEnabled = false
        this.blendModes = 0
        cab ? this.cacheAsBitmap = true : this.cacheAsBitmap = false
        this.smoothed = true
        this.body = null

        this.anchor.setTo(0.5,0.5);
        this.alive = false
        this.checkWorldBounds = false
        this.pivot.setTo(0.5,0.5)
        return this;
    }
    Btn.prototype = Object.create(Phaser.Sprite.prototype);
    Btn.prototype.constructor = Btn
    //-------------------------------------------

    //-------------------------------------------
    var Slot_symbols = function _Slot_symbols(x,y,img,center,cab){
            Phaser.Image.call(this, gamex, x, y);
            this.input = new Phaser.InputHandler(this)
            this.inputEnabled = false
            this.blendModes = 0
            this.body = null
            this.anchor.setTo(0.5,0.5);
            this.alive = false
            this.checkWorldBounds = false
            this.pivot.setTo(0.5,0.5)
            this.bg = new Pic(0,0,"sym1");
            this.addChild(this.bg);
            this.bg.key = 'sym2'
            this.bg.pivot.setTo(0.5,0.5)
            return this;
    }
    Slot_symbols.prototype = Object.create(Phaser.Image.prototype);
    Slot_symbols.prototype.constructor = Slot_symbols
    //-------------------------------------------

    //-------------------------------------------
        var Slot_reels = function _Slot_reels(x,y,img,center,cab){
            Phaser.Sprite.call(this, gamex, x, y);
            this.input = new Phaser.InputHandler(this)
            this.inputEnabled = false
            this.blendModes = 0
            this.smoothed = true
            this.body = null

            this.anchor.setTo(0.5,0.5);
            this.alive = false
            this.checkWorldBounds = false
            this.pivot.setTo(0.5,0.5)

            this.sym = new Array();

            this.sym[0] = new Slot_symbols(0,0,"",true);
            this.addChild(this.sym[0])
            this.sym[0].y = 0
            this.sym[0].bg.loadTexture("sym2")

            this.sym[1] = new Slot_symbols();
            this.addChild(this.sym[1])
            this.sym[1].y = 180

            this.sym[2] = new Slot_symbols();
            this.addChild(this.sym[2])
            this.sym[2].y = 360
            this.sym[2].bg.loadTexture("sym3")

            return this;
    }
    Slot_reels.prototype = Object.create(Phaser.Sprite.prototype);
    Slot_reels.prototype.constructor = Slot_reels
    //-------------------------------------------

    //-------------------------------------------
        var Slot_machine = function _Slot_machine(x,y,slot){
            Phaser.Sprite.call(this, gamex, x, y);
            this.input = new Phaser.InputHandler(this)
            this.inputEnabled = false
            this.blendModes = 0
            this.smoothed = true
            this.body = null
            this.anchor.setTo(0.5,0.5);
            this.alive = false
            this.checkWorldBounds = false
            this.pivot.setTo(0.5,0.5)

            var TL = new TimelineMax();
            var stop_TL = new TimelineMax();
            var self = this
            var spd = 75

            var lines = [[0],
                [1,1,1,1,1],//1
                [0,0,0,0,0],//2
                [2,2,2,2,2],//3
                [0,1,2,1,0],//4
                [2,1,0,1,2],//5
                [0,0,1,0,0],//6
                [2,2,1,2,2],//7
                [1,0,0,0,1],//8
                [1,2,2,2,1],//9
                [0,1,1,1,0],//10
                [2,1,1,1,2],//11
                [0,1,0,1,0],//12
                [2,1,2,1,2],//13
                [1,0,1,0,1],//14
                [1,2,1,2,1],//15
                [1,1,0,1,1],//16
                [1,1,2,1,1],//17
                [0,2,0,2,0],//18
                [2,0,2,0,2],//19
                [1,0,2,0,1],//20
                [1,2,0,2,1],//21
                [0,0,2,0,0],//22
                [2,2,0,2,2],//23
                [0,2,2,2,0],//24
                [2,0,0,0,2],//25
                [2,0,1,0,2],//26
                [0,2,1,2,0],//27
                [0,0,1,2,2],//28
                [2,2,1,0,0],//29
                [1,0,1,2,1]//30
            ];

            this.stat = 2 //2=1st//1=stop//0=disabled
            this.forced_stop = false
            this.spinning = false

            this.bg = gamex.add.graphics(0,0)
            this.bg.beginFill(0x3300ca)
            this.addChild(this.bg);
            //this.bg.lineStyle(10,0xff0000)
            this.bg.drawRoundedRect(-460, -110, 920,560,20);
            this.bg.alpha = 0.1
            //this.bg.blendMode = 10

            this.paylines = new Slot_paylines(0,0,slot)
            this.addChild(this.paylines)

            this.reels = new Array();
            //-------------------------------
            this.reels[0] = new Slot_reels();
            this.addChild(this.reels[0])

            this.reels[0].x = -352

            this.reels[1] = new Slot_reels();
            this.addChild(this.reels[1])
            this.reels[1].x = -176

            this.reels[2] = new Slot_reels();
            this.addChild(this.reels[2])
            this.reels[2].x = 0

            this.reels[3] = new Slot_reels();
            this.addChild(this.reels[3])
            this.reels[3].x = 176

            this.reels[4] = new Slot_reels();
            this.addChild(this.reels[4])
            this.reels[4].x = 352

            this.reels[5] = new Slot_reels();
            this.addChild(this.reels[5])
            this.reels[5].x = -352
            this.reels[5].y = -540

            this.reels[6] = new Slot_reels();
            this.addChild(this.reels[6])
            this.reels[6].x = -176
            this.reels[6].y = -540

            this.reels[7] = new Slot_reels();
            this.addChild(this.reels[7])
            this.reels[7].x = 0
            this.reels[7].y = -540

            this.reels[8] = new Slot_reels();
            this.addChild(this.reels[8])
            this.reels[8].x = 176
            this.reels[8].y = -540

            this.reels[9] = new Slot_reels();
            this.addChild(this.reels[9])
            this.reels[9].x = 352
            this.reels[9].y = -540

            this.mini_win_holder = new Slot_win_holder_mini(0,0,slot);
            this.addChild(this.mini_win_holder)
            this.mini_win_holder.visible = false




            this.gamble_game = new Slot_Gamble_Game(0,0,slot)
            this.addChild(this.gamble_game);

            this.fast_spin_bg

            //-------------------------------
            this.maskee1 = gamex.add.graphics(0,0)
            this.maskee1.beginFill(0xffffff)
            this.maskee1.drawRect(-460, -110, 920,560);
            this.addChild(this.maskee1);
        
            this.mask = this.maskee1

            this.go_spin = function(){
                if(self.stat > 0 ){
                    if(self.stat == 2 && slot.auto_spin_num>0){
                        slot.auto_spin_num -= 1
                        slot.controls.update_auto_text();
                    }
                    if(self.spinning){
                        self.forced_stop = true
                        self.go_stop();
                    }else{
                        slot.be.reset_response();

                        slot.fast_spin = 0
                        self.mini_win_holder.visible = false
                        self.mini_win_holder.y = 0

                        if(slot.be.numFR==0){
                            slot.be.request_spin(slot,1)
                            slot.lower_bar.win_bar.textf.text.setText("0")
                        }else
                        if(slot.be.numFR==1){
                            slot.be.request_free_spin(slot,1)
                            //slot.lower_bar.win_bar.textf.text.setText("0")
                        }

                        self.slot_spin = [1,1,1,1,1]
                        self.spinning = true
                        TweenMax.to(self,1,{onUpdate:updates,repeat:-1})
                        TweenMax.to(self,slot.turbo ? 0.25 : 0.5 ,{onComplete:self.go_stop})
                        TweenMax.to(slot.lower_bar.slot_bet_slider,0.25,{y:50,ease:Back.easeOut})
                        TweenMax.to(slot.lower_bar.slot_line_slider,0.25,{y:50,ease:Back.easeOut})
                    }
                    if(slot.auto_spin_num>0){
                        slot.auto_spin_mode = true
                    }
                    self.stat -= 1
                    self.clear_winning_lines();//to reset reels status
                    TL.clear();
               }
            }

            function updates(m,n){
                if(self.spinning == true){
                    if(self.slot_spin[0]==1){
                        self.reels[0].y += spd
                        self.reels[5].y += spd
                        if(self.reels[0].y >= 540){self.reels[0].y = -540}
                        if(self.reels[5].y >= 540){self.reels[5].y = -540}
                    }
                    if(self.slot_spin[1]==1){
                        self.reels[1].y -= spd
                        self.reels[6].y -= spd
                        if(self.reels[1].y <= -540){self.reels[1].y = 540}
                        if(self.reels[6].y <= -540){self.reels[6].y = 540}
                    }
                    if(self.slot_spin[2]==1){
                        self.reels[2].y += spd
                        self.reels[7].y += spd
                        if(self.reels[2].y >= 540){self.reels[2].y = -540}
                        if(self.reels[7].y >= 540){self.reels[7].y = -540}
                    }
                    if(self.slot_spin[3]==1){
                        self.reels[3].y -= spd
                        self.reels[8].y -= spd
                        
                        if(self.reels[3].y <= -540){self.reels[3].y = 540}
                        if(self.reels[8].y <= -540){self.reels[8].y = 540}
                    }
                    if(self.slot_spin[4]==1){
                        self.reels[4].y += spd
                        self.reels[9].y += spd
                        if(self.reels[4].y >= 540){self.reels[4].y = -540}
                        if(self.reels[9].y >= 540){self.reels[9].y = -540}
                    }
                }
            }


            this.clear_winning_lines = function(i){
                self.paylines.line.clear();
                for(i=0;i<5;i++){
                    TweenMax.killTweensOf(self.reels[i].sym[0].scale)
                    TweenMax.killTweensOf(self.reels[i].sym[1].scale)
                    TweenMax.killTweensOf(self.reels[i].sym[2].scale)
                    self.reels[i].sym[0].scale.setTo(1)
                    self.reels[i].sym[1].scale.setTo(1)
                    self.reels[i].sym[2].scale.setTo(1)
                }
                self.paylines.hide_line_bg();
            }

            this.clear_spin_animation = function(){
                self.slot_spin = [0,0,0,0,0]
                TweenMax.killTweensOf(self.slot_spin)
                TweenMax.killTweensOf(self)
                for(i=0;i<10;i++){  
                    TweenMax.killTweensOf(self.reels[i])  
                }
            }

            this.update_slot_symbols = function(){
                    self.reels[0].sym[0].bg.loadTexture(slot.sym_name[  Number(slot.be.R[0][ Number(slot.be.S[0]) != 0 ? Number(slot.be.S[0]) -1  : Number(slot.be.R[0].length) -1])])
                    self.reels[0].sym[1].bg.loadTexture(slot.sym_name[  Number(slot.be.R[0][ Number(slot.be.S[0]) -0])  ])
                    self.reels[0].sym[2].bg.loadTexture(slot.sym_name[  Number(slot.be.R[0][ Number(slot.be.S[0]) +1])  ])
                    self.reels[1].sym[0].bg.loadTexture(slot.sym_name[  Number(slot.be.R[1][ Number(slot.be.S[1]) != 0 ? Number(slot.be.S[1]) -1  : Number(slot.be.R[1].length) -1])])
                    self.reels[1].sym[1].bg.loadTexture(slot.sym_name[  Number(slot.be.R[1][ Number(slot.be.S[1]) -0])  ])
                    self.reels[1].sym[2].bg.loadTexture(slot.sym_name[  Number(slot.be.R[1][ Number(slot.be.S[1]) +1])  ])
                    self.reels[2].sym[0].bg.loadTexture(slot.sym_name[  Number(slot.be.R[2][ Number(slot.be.S[2]) != 0 ? Number(slot.be.S[2]) -1  : Number(slot.be.R[2].length) -1])])
                    self.reels[2].sym[1].bg.loadTexture(slot.sym_name[  Number(slot.be.R[2][ Number(slot.be.S[2]) -0])  ])
                    self.reels[2].sym[2].bg.loadTexture(slot.sym_name[  Number(slot.be.R[2][ Number(slot.be.S[2]) +1])  ])
                    self.reels[3].sym[0].bg.loadTexture(slot.sym_name[  Number(slot.be.R[3][ Number(slot.be.S[3]) != 0 ? Number(slot.be.S[3]) -1  : Number(slot.be.R[3].length) -1])])
                    self.reels[3].sym[1].bg.loadTexture(slot.sym_name[  Number(slot.be.R[3][ Number(slot.be.S[3]) -0])  ])
                    self.reels[3].sym[2].bg.loadTexture(slot.sym_name[  Number(slot.be.R[3][ Number(slot.be.S[3]) +1])  ])
                    self.reels[4].sym[0].bg.loadTexture(slot.sym_name[  Number(slot.be.R[4][ Number(slot.be.S[4]) != 0 ? Number(slot.be.S[4]) -1  : Number(slot.be.R[4].length) -1])])
                    self.reels[4].sym[1].bg.loadTexture(slot.sym_name[  Number(slot.be.R[4][ Number(slot.be.S[4]) -0])  ])
                    self.reels[4].sym[2].bg.loadTexture(slot.sym_name[  Number(slot.be.R[4][ Number(slot.be.S[4]) +1])  ])
            }
            
            this.go_stop = function(){

                //check fast spin
                if(slot.be.SW.length > 3){
                    slot.fast_spin = 1
                }

                if(slot.be.SW.length > 5){
                    slot.fast_spin = 2
                }

                if(slot.be.numFR == 3){
                    slot.fast_spin = 3
                }

                this.spd = 0.25
                this.delay = 0.2
                self.update_slot_symbols();
                if(!self.forced_stop){
                        //normal spin

                        stop_TL.clear();
                        
                        stop_TL.appendMultiple([TweenMax.to(self.slot_spin,this.spd,{[0]:0,delay:this.delay}),
                                                TweenMax.to(self.reels[0],this.spd,{delay:this.delay,y:0,startAt:{y:-540},ease:Back.easeOut,onComplete:function(){}}),   
                                                TweenMax.to(self.reels[5],this.spd,{delay:this.delay,y:540,startAt:{y:0},ease:Back.easeOut,onComplete:function(){}})
                                                ])

                        stop_TL.appendMultiple([TweenMax.to(self.slot_spin,this.spd,{[1]:0,delay:this.delay}),
                                                TweenMax.to(self.reels[1],this.spd,{delay:this.delay,y:0,startAt:{y:540},ease:Back.easeOut,onComplete:function(){}}),
                                                TweenMax.to(self.reels[6],this.spd,{delay:this.delay,y:-540,startAt:{y:0},ease:Back.easeOut,onComplete:function(){}})
                                                ])

                        if(slot.fast_spin == 1 || slot.fast_spin == 2){stop_TL.append(TweenMax.delayedCall(2,function(){/* */}))   }

                        stop_TL.appendMultiple([TweenMax.to(self.slot_spin,this.spd,{[2]:0,delay:this.delay}),
                                                TweenMax.to(self.reels[2],this.spd,{delay:this.delay,y:0,startAt:{y:-540},ease:Back.easeOut,onComplete:function(){}}),   
                                                TweenMax.to(self.reels[7],this.spd,{delay:this.delay,y:540,startAt:{y:0},ease:Back.easeOut,onComplete:function(){}})
                                                ])

                        if(slot.fast_spin == 2){stop_TL.append(TweenMax.delayedCall(2,function(){/* */}))   }

                        stop_TL.appendMultiple([TweenMax.to(self.slot_spin,this.spd,{[3]:0,delay:this.delay}),
                                                TweenMax.to(self.reels[3],this.spd,{delay:this.delay,y:0,startAt:{y:540},ease:Back.easeOut,onComplete:function(){}}),
                                                TweenMax.to(self.reels[8],this.spd,{delay:this.delay,y:-540,startAt:{y:0},ease:Back.easeOut,onComplete:function(){}})
                                                ])

                        if(slot.fast_spin == 3){stop_TL.append(TweenMax.delayedCall(2,function(){/* */}))   }

                        stop_TL.appendMultiple([TweenMax.to(self.slot_spin,this.spd,{[4]:0,delay:this.delay}),
                                                TweenMax.to(self.reels[4],this.spd,{delay:this.delay,y:0,startAt:{y:-540},ease:Back.easeOut,onComplete:function(){}}),   
                                                TweenMax.to(self.reels[9],this.spd,{delay:this.delay,y:540,startAt:{y:0},ease:Back.easeOut,onComplete:function(){}})
                                                ])

                        stop_TL.append(TweenMax.delayedCall(this.spd+0.5,self.stop_reels)     )

                        stop_TL.play()
                }else{
                        self.clear_spin_animation();
                        //force stop
                        if(self.slot_spin != [0,1,1,1,1]){
                            TweenMax.to(self.reels[0],this.spd,{delay:0,y:0,startAt:{y:-540},ease:Back.easeOut,onComplete:function(){}})
                            TweenMax.to(self.reels[5],this.spd,{delay:0,y:540,startAt:{y:0},ease:Back.easeOut,onComplete:function(){}})
                        }
                        if(self.slot_spin != [0,0,1,1,1]){
                            TweenMax.to(self.reels[1],this.spd,{delay:0,y:0,startAt:{y:540},ease:Back.easeOut,onComplete:function(){}})
                            TweenMax.to(self.reels[6],this.spd,{delay:0,y:-540,startAt:{y:0},ease:Back.easeOut,onComplete:function(){}})
                        }
                        if(self.slot_spin != [0,0,0,1,1]){
                            TweenMax.to(self.reels[2],this.spd,{delay:0,y:0,startAt:{y:-540},ease:Back.easeOut,onComplete:function(){}})
                            TweenMax.to(self.reels[7],this.spd,{delay:0,y:540,startAt:{y:0},ease:Back.easeOut,onComplete:function(){}})
                        }
                        if(self.slot_spin != [0,0,0,0,1]){
                            TweenMax.to(self.reels[3],this.spd,{delay:0,y:0,startAt:{y:540},ease:Back.easeOut,onComplete:function(){}})
                            TweenMax.to(self.reels[8],this.spd,{delay:0,y:-540,startAt:{y:0},ease:Back.easeOut,onComplete:function(){}})
                        }
                        if(self.slot_spin != [0,0,0,0,0]){
                            TweenMax.to(self.reels[4],this.spd,{delay:0,y:0,startAt:{y:-540},ease:Back.easeOut,onComplete:function(){}})
                            TweenMax.to(self.reels[9],this.spd,{delay:0,y:540,startAt:{y:0},ease:Back.easeOut,onComplete:function(){}})
                        }
                        TweenMax.killDelayedCallsTo(self.stop_reels);
                        TweenMax.delayedCall(this.spd+0.75,self.stop_reels)
                }
            }

            this.stop_reels = function(){
                self.spinning = false;
                TweenMax.killTweensOf(self);
                slot.turbo ? self.forced_stop = true : self.forced_stop = false
                self.stat = 2
                //RESPIN
                if(slot.be.WIN == 0 && slot.auto_spin_num > 0){ TweenMax.delayedCall(1,self.go_spin);   }

                if(slot.auto_spin_num == 0 && slot.be.LS != null){    
                    slot.auto_spin_mode = false ;
                    TweenMax.delayedCall(1,self.change_screen,["normal"]);
                }

                self.animate_all_win();
            }

            var i = 0;
            this.update_slot_symbols();

            this.animate_single_win = function(num,len,clearing,single,j){
                    var i = 0;

                    !clearing ? 0 : self.clear_winning_lines()
                    !single ? many = false : single = true
                       
                    this.syms = [];//symbols to animate
                    for(i=0;i<len;i++){
                        this.syms[i] = self.reels[i].sym[lines[num][i]].scale
                    }
                    self.paylines.draw_lines([num])   
                    TweenMax.allTo(this.syms,0.25,{x:1.15,y:1.15,repeat:3,yoyo:true})

                    TweenMax.to(self.mini_win_holder.scale,0.25,{x:1.3,y:1.3,repeat:3,yoyo:true});

                    if(single){
                        self.mini_win_holder.visible = true
                        self.mini_win_holder.y = (lines[num][2] * 180)
                        self.mini_win_holder.textf.text.setText(NumCom(slot.be.L[j].split(";")[1]))
                    }

            }

            this.animate_scatter = function(i){
                this.syms = []
                if(slot.be.SW.length>0){
                    for(i=0;i<slot.be.SW.length-2;i++){
                         this.syms[i] = self.reels[i].sym[slot.be.SW[i+1].split(":")[0]].scale
                    }
                    return TweenMax.allTo(this.syms,0.25,{x:1.15,y:1.15,repeat:3,yoyo:true})
                }
            }

            this.animate_all_win = function(arr_num,arr_len,i){

                    slot.lower_bar.win_bar.textf.text.setText(NumCom(slot.be.WIN))
                    slot.lower_bar.credit_bar.textf.text.setText(NumCom(slot.be.C))

                    self.clear_winning_lines();
                    TL.clear();
                    TL = new TimelineMax();
                    slot.be.LW = []

                    if(slot.be.SW.length-2 < 3 && (slot.be.SW.length != 0 || slot.be.L.length > 0) ){
                        if(slot.be.SW.length>0){
                            TL.append(  TweenMax.delayedCall( slot.be.L.length>0 ? 1.5 : 0.5 ,self.animate_scatter)    );
                        }

                        if(slot.be.L.length > 0){
                            for(i=0;i<slot.be.L.length;i++){
                                slot.be.LW[i] = slot.be.L[i].split(";")
                                self.animate_single_win(Number(slot.be.LW[i][0]),slot.be.LW[i].length-3,false,false )
                                self.animate_scatter();
                                TL.append(TweenMax.delayedCall(1.5,self.animate_single_win,[ Number(slot.be.LW[i][0]) , slot.be.LW[i].length-3 ,  true ,true,i]))
                            }
                        }

                        TL.play();
                        if(slot.auto_spin_mode){
                            if(slot.auto_spin_num > 0){ TL.append(TweenMax.delayedCall(2,self.go_spin) ) }
                            TL.repeat(0) 
                        }else{ 
                            TL.repeat(-1)
                        }
                    }else
                    if(slot.be.SW.length-2>2){
                        trace('go to free')
                        self.animate_scatter();
                        TweenMax.delayedCall(1,self.change_screen,["free"])
                    }//*/
            }

            this.change_screen = function(scene){
                if(scene== "free"){
                        if(slot.be.numFR == 1){
                            slot.bg.loadTexture("bg");
                            slot.controls.auto_btn.inputEnabled = false
                            if(slot.controls != undefined){
                                slot.controls.spin_btn.tint = 0x660000
                            }
                           
                            if(slot.be.response == -1){
                                self.draw_freespin_flier()
                            }
                        }
                }else
                if(scene == "normal"){
                        slot.be.response = -1
                        slot.be.update_R();
                        self.update_slot_symbols();
                        slot.bg.loadTexture("bg2");
                        slot.controls.auto_btn.inputEnabled = true
                }
            }

            this.draw_freespin_flier = function(){
                self.free_option = new Slot_Free_Flier(0,0,slot)//640,180
                self.addChild(self.free_option)
                //slot.controls.inputEnabled = false
                /*slot.slot_game_holder.addChild(self.free_option)
                slot.slot_game_holder.bringToTop(self.free_option);*/
            }


            this.remove_free_spin_flier = function(){
                self.free_option.destroy();
            }

        return this;
    }
    Slot_machine.prototype = Object.create(Phaser.Sprite.prototype);
    Slot_machine.prototype.constructor = Slot_machine
    //-------------------------------------------

    //-------------------------------------------
    var Slot_upper_bar = function _Slot_upper_bar(x,y,slot){
        Phaser.Sprite.call(this, gamex, x, y);
        this.input = new Phaser.InputHandler(this)
        this.inputEnabled = false
        this.blendModes = 0
        this.smoothed = true
        this.body = null

        this.anchor.setTo(0.5,0.5);
        this.alive = false
        this.checkWorldBounds = false
        this.pivot.setTo(0.5,0.5)

        this.bg = new Pic(640,0,"bottom_bar");
        this.addChild(this.bg);
        this.bg.tint = 0x0
        this.bg.alpha = 0.1

        this.bg.pivot.setTo(0.5,0.5)

        this.promo_msg = new Sprite(490,5,"bottom_bar");
        this.addChild(this.promo_msg);
        this.promo_msg.pivot.setTo(0,0.5)
        this.promo_msg.anchor.setTo(0,0.5)
        this.promo_msg.scale.setTo(0.55,0.6)
        this.promo_msg.tint = 0x0
        this.promo_msg.alpha = 0.5

        this.btn_menu = new Pic(40,18,"btn");
        this.addChild(this.btn_menu);
        this.btn_menu.frameName = "btn_menu0000"
        this.btn_menu.tint = 0xcccccc
        this.btn_menu.pivot.setTo(0.5,0.5)

        this.btn_full_screen = new Pic(1240,18,"btn");
        this.addChild(this.btn_full_screen);
        this.btn_full_screen.frameName = "btn_fullscreen0000"
        this.btn_full_screen.tint = 0xccccc    
        this.btn_full_screen.pivot.setTo(0.5,0.5)

        this.promo_txt = new TextField("hit the correct combo to win in bonus game",15)//_TextField(game,str,w,h,style,sz,border){
        this.promo_txt.x = 500
        this.promo_txt.y = -2
        this.promo_txt.text.tint = 0xfffcc00
        this.addChild(this.promo_txt)

        this.logo = new Pic(0,0,"logo");
        this.addChild(this.logo);
        this.logo.x = 280
        this.logo.y = 25
        //this.logo.tint = 0xcc0000
        this.logo.pivot.setTo(0.5,0.5)
        return this;

    }
    Slot_upper_bar.prototype = Object.create(Phaser.Sprite.prototype);
    Slot_upper_bar.prototype.constructor = Slot_upper_bar
    //-------------------------------------------

    //-------------------------------------------
    var Slot_lower_bar = function _Slot_lower_bar(x,y,slot){
        Phaser.Sprite.call(this, gamex, x, y);
        this.input = new Phaser.InputHandler(this)
        this.inputEnabled = false
        this.blendModes = 0
        this.smoothed = true
        this.body = null
        var self = this;

        this.anchor.setTo(0.5,0.5);
        this.alive = false
        this.checkWorldBounds = false
        this.pivot.setTo(0.5,0.5)

        this.char1 = new Pic(90,-130/*-190*/,"char2");
        this.char1.scale.setTo(-1,1)
        this.addChild(this.char1);

        this.slot_line_slider = new Slot_slider(275,50,1,28,null,slot);
        this.addChild(this.slot_line_slider)

        this.slot_bet_slider = new Slot_slider(55,50,1,slot.be.BPL.length,slot.be.BPL,slot);
        this.addChild(this.slot_bet_slider)

        this.bg = new Pic(640,18,"bottom_bar");
        this.addChild(this.bg);
        this.bg.alpha = 0.1
        this.bg.tint = 0x0
        this.bg.pivot.setTo(0.5,0.5)

        this.bet_holder = new Slot_button_text_holder(70,12);
        this.bet_holder.textf.text.setText("10")
        this.bet_holder.icon.y = -10
        this.addChild(this.bet_holder);

        this.line_holder = new Slot_button_text_holder(280,12);
        this.line_holder.icon.frameName = "btn_line0000"
        this.line_holder.icon.y = -10
        this.line_holder.textf.text.setText("100")
        this.addChild(this.line_holder);

        this.total_bet = new Slot_button_text_holder(475,12);//530
        this.total_bet.textf.text.setText("1,000")
        this.total_bet.icon.frameName = "btn_totalbet0000"
        this.total_bet.icon.tint = 0xcc6600;
        //this.total_bet.icon.scale.setTo(0.7)
        this.addChild(this.total_bet);

        this.win_bar = new Slot_button_text_holder(670,12,'left',270);
        this.addChild(this.win_bar);
        this.win_bar.textf.text.setText("0")
        this.win_bar.icon.frameName = "btn_credit0000"
        this.win_bar.icon.tint = 0xcc6600;
        //this.win_bar.icon.scale.setTo(0.7)

        this.credit_bar = new Slot_button_text_holder(1000,12,'left',270);
        this.addChild(this.credit_bar);
        this.credit_bar.textf.text.setText("1,000")
        this.credit_bar.icon.frameName = "btn_credit0000"
        this.credit_bar.icon.tint = 0xcc6600;
        //this.credit_bar.icon.scale.setTo(0.7)

        //update both
        this.update_bet_and_line = function(bet,line,o){
            !bet ? bet = 30 : 0 ;
            !line ? line = 1 : 0 ;
            self.bet_holder.textf.text.setText(slot.be.BPL[slot.be.BET])
            self.line_holder.textf.text.setText(slot.be.N)

            var txt = ""
            txt = NumRound(Number(slot.be.BPL[slot.be.BET]) * (slot.be.N))
            self.total_bet.textf.text.setText(txt)
        }

        this.update_bet_slider = function(){
            var txt = ""
            slot.be.BET = self.slot_bet_slider.id
            self.bet_holder.textf.text.setText(slot.be.BPL[slot.be.BET])
            txt = NumRound(Number(slot.be.BPL[slot.be.BET]) * (slot.be.N))
            self.total_bet.textf.text.setText(txt)
        }

        this.update_line_slider = function(){
            var txt = ""
            slot.be.N = self.slot_line_slider.id + 1
            self.line_holder.textf.text.setText(slot.be.N)
            txt = NumRound(Number(slot.be.BPL[slot.be.BET]) * (slot.be.N))
            self.total_bet.textf.text.setText(txt)
        }

        this.slot_line_slider.set_val_slider = this.update_line_slider
        this.slot_bet_slider.set_val_slider = this.update_bet_slider

        this.set_bet = function(o){
            if(o == slot.lower_bar.slot_bet_slider.btn_down){
                slot.be.BET -= 1
            }else{
                slot.be.BET += 1
            }
            var txt = slot.be.BPL[slot.be.BET] + ""
            self.bet_holder.textf.text.setText(txt)

            txt = NumRound(Number(slot.be.BPL[slot.be.BET]) * (slot.be.N))
            self.total_bet.textf.text.setText(txt)
        }

        this.set_line = function(o){
            if(o == slot.lower_bar.slot_line_slider.btn_down){
                slot.be.N -= 1
            }else{
                slot.be.N += 1
            }
            self.line_holder.textf.text.setText(slot.be.N)

            var txt = ""
            txt = NumRound(Number(slot.be.BPL[slot.be.BET]) * (slot.be.N))
            self.total_bet.textf.text.setText(txt)
        }

        this.slot_bet_slider.set_val = this.set_bet

        this.slot_line_slider.set_val = this.set_line

        return this;
    }
    Slot_lower_bar.prototype = Object.create(Phaser.Sprite.prototype);
    Slot_lower_bar.prototype.constructor = Slot_lower_bar
    //-------------------------------------------

    
    var Slot_slider = function _Slot_slider(x,y,min,max,arr,slot,center){
        Phaser.Sprite.call(this, gamex, x, y);
        this.inputEnabled = false
        this.blendModes = 0
        this.input = new Phaser.InputHandler(this)
        this.body = null
        this.anchor.setTo(0.5,0.5);
        this.alive = false
        this.checkWorldBounds = false
        this.pivot.setTo(0.5,0.5)
        var self = this;

        this.str = ""
        this.def_arr = []
        this.id = 0

        !max ? max = 0 : 0;
        !min ? min = 0 : 0;
        !arr ? arr = this.def_arr : 0 ;

        for(k=1;k<31;k++){
            this.def_arr.push(k)
        }

        for(i=arr.length;i>0;i--){
            this.str = String(this.str + "" + arr[i-1] +"\n")
        }

        this.bg2 = gamex.add.graphics(0,0)
        this.bg2.beginFill(0x101010)
        this.addChild(this.bg2);
        //this.bg2.lineStyle(2,0xff0000,0.9)
        this.bg2.drawRoundedRect(30, 0, 120,380,20);
        this.bg2.alpha = 0.95

        this.text1 = new TextField(this.str,34,90,160,'center')
        this.text1.text.lineSpacing = 40
        this.text1.text.tint = 0xffcc00
        this.text1.text.anchor.setTo(0.5,0)
        this.addChild(this.text1)
        this.text1.inputEnabled = false
        this.text1.y = 90 - (82*((this.id)-1))
        this.text1.input.enableSnap(6, 82, true, true);

        this.num_mask = gamex.add.graphics(0,0)
        this.num_mask.beginFill(0x050505)
        this.addChild(this.num_mask);
        this.num_mask.drawRect(30, 90, 120,180);
        this.num_mask.alpha = 0.95
        this.text1.mask = this.num_mask

        this.bg = new Pic(90,170,"transparent_gradient");
        this.addChild(this.bg);
        this.bg.pivot.setTo(0.5,0.5)
        this.bg.scale.setTo(1.25,0.75)

        this.btn_up = new Pic(90,40,"btn");
        this.addChild(this.btn_up);
        //this.btn_up.scale.setTo(1.8,1.2)
        this.btn_up.frameName = "btn_up0000"
        this.btn_up.tint = 0xffaa00;
        this.btn_up.pivot.setTo(0.5,0.5)
        this.btn_up.input.priorityID = 2

        this.btn_down = new Pic(90,320,"btn");
        this.addChild(this.btn_down);
        //this.btn_down.scale.setTo(1.8,1.2)
        this.btn_down.frameName = "btn_down0000"
        this.btn_down.tint = 0xffaa00;
        this.btn_down.pivot.setTo(0.5,0.5)
        this.btn_down.input.priorityID = 2

        Drag(self.text1,drag_s,drag_e,1,false)
        this.text1.input.enableDrag(false,false,false,false,new Phaser.Rectangle(60, -(this.text1.text.height-328), 80,this.text1.text.height-164));
        this.text1.input.allowHorizontalDrag = false

        self.text1.input.priorityID = 3
        this.bg.input.priorityID = 3
        this.input.priorityID = 3

        function drag_s(){}

        this.pos = 0

        this.set_val_slider = function _set_val_slider(){}

        function drag_e(){
            self.pos = (self.text1.y -164)
            self.id = (-(self.pos /82) - (arr.length-1) )*-1
            self.set_val_slider();
        }

        this.set_val = function(){}

        this.change_bet = function(o){
            if(max!= 0 && min !=0 && self.y == -380){
                if(o == self.btn_up && self.text1.y<= (min*90) ){
                    self.text1.y += 82
                    self.id-=1
                    self.set_val(o);
                }else
                if(o == self.btn_down && self.text1.y >= -((max-4)*90)){
                    self.text1.y -= 82
                    self.id+=1
                    self.set_val(o);
                }
            }
        }

        Tap(this.btn_up,self.change_bet)
        Tap(this.btn_down,self.change_bet)
        this.btn_up.input.priorityID = 4
        this.btn_down.input.priorityID = 4

        return this;
    }
    Slot_slider.prototype = Object.create(Phaser.Sprite.prototype);
    Slot_slider.prototype.constructor = Slot_slider
    //-------------------------------------------

   //-------------------------------------------
    var Slot_button_text_holder = function _Slot_button_text_holder(x,y,align,bg_width){
        Phaser.Sprite.call(this, gamex, x, y);
        this.input = new Phaser.InputHandler(this)
        this.inputEnabled = false
        this.blendModes = 0
        this.smoothed = true
        this.body = null

        this.anchor.setTo(0.5,0.5);
        this.alive = false
        this.checkWorldBounds = false
        this.pivot.setTo(0.5,0.5)
        this.tint = 0x330000;

        !bg_width ? bg_width = 140 : 0 ;

        this.bg = new Pic(0,0,"bottom_bar");
        this.addChild(this.bg);
        this.bg.width = bg_width;
        this.bg.tint = 0x0
        this.bg.alpha = 0.7
        this.bg.scale.y = 0.6
        this.bg.anchor.setTo(0,0.5);
        this.bg.pivot.setTo(0,0.5);

        this.icon = new Pic(-16,0,"btn");
        this.addChild(this.icon);
        this.icon.frameName = "btn_bet0000"
        this.icon.tint = 0xffffff;
        this.icon.pivot.setTo(0.5,0.5)

        !align ? align = 'center' : 0;

        this.textf = new TextField("str",20,70,5,align)///_TextField(game,str,w,h,style,sz,border){
        this.textf.text.tint = 0xffdd00
        this.textf.anchor.setTo(0,0.5)
        this.addChild(this.textf)

        align == 'center' ? this.textf.x = 70 : this.textf.x = 20
        align == 'center' ? this.textf.y = 5 : this.textf.y = -8

        return this;
    }
    Slot_button_text_holder.prototype = Object.create(Phaser.Sprite.prototype);
    Slot_button_text_holder.prototype.constructor = Slot_button_text_holder
    //-------------------------------------------

    //-------------------------------------------
    var Slot_controls = function _Slot_controls(x,y,slot){
        Phaser.Sprite.call(this, gamex, x, y);
        this.inputEnabled = false
        this.blendModes = 0
        this.input = new Phaser.InputHandler(this)
        this.body = null
        this.anchor.setTo(0.5,0.5);
        this.alive = false
        this.checkWorldBounds = false
        this.pivot.setTo(0.5,0.5)

        this.allow_auto_spin = true

        var self = this;
        var active = true

        this.opened = false

        this.spin_btn = new Sprite(0,0,"spin_btn");
        this.addChild(this.spin_btn);
        this.spin_btn.pivot.setTo(0.5,0.5)
        this.smoothed = false

        this.gamble_btn = new Sprite(0,-170,"btn_auto");
        this.addChild(this.gamble_btn);
        this.gamble_btn.pivot.setTo(0.5,0.5)
        //this.gamble_btn.visible = false
        //this.gamble_btn.tint = 0xffff66
        this.smoothed = false

        //bar
        this.auto_bar = new Sprite(660,0)
        this.addChild(this.auto_bar )

        this.maskee = gamex.add.graphics(-660,105)
        this.maskee.beginFill(0xffffff)
        this.addChild(this.maskee);
        this.maskee.drawRect(0, 0, 650,80);
        this.auto_bar.mask = this.maskee

        //TweenMax.to(this.auto_bar,0.25,{x:540,repeat:-1,yoyo:true,repeatDelay:3})

        this.auto_bg = gamex.add.graphics(-655,160)
        this.auto_bg.beginFill(0x101010)
        this.auto_bg.drawRect(0, -15, 620,50)
        this.auto_bg.lineStyle(2,0x999999,2)
        this.auto_bg.alpha = 0.65

        this.auto_bar.addChild(this.auto_bg);
        
        this.auto_btn = new Sprite(0,165,"btn_auto");
        this.addChild(this.auto_btn);
        //this.auto_btn.scale.setTo(0.85,0.85)
        this.auto_btn.pivot.setTo(0.5,0.5)
        this.auto_btn.anchor.setTo(0.5,0.5)
        this.auto_btn.smoothed = false

        this.bt1 = new BlankBtn(-610,150,"btn","btn_blank0000",'10')
        this.bt1.scale.setTo(1.2)
        this.bt1.textf.x = -14
        this.bt1.textf.text.tint = 0xcccccc
        this.auto_bar.addChild(this.bt1)

        this.bt2 = new BlankBtn(-510,150,"btn","btn_blank0000",'20')
        this.bt2.scale.setTo(1.2)
        this.bt2.textf.x = -16
        this.bt2.textf.text.tint = 0xcccccc
        this.auto_bar.addChild(this.bt2)

        this.bt3 = new BlankBtn(-410,150,"btn","btn_blank0000",'50')
        this.bt3.scale.setTo(1.2)
        this.bt3.textf.x = -16
        this.bt3.textf.text.tint = 0xcccccc
        this.auto_bar.addChild(this.bt3)

        this.bt4 = new BlankBtn(-310,150,"btn","btn_blank0000",'100')
        this.bt4.scale.setTo(1.2)
        this.bt4.textf.x = -20
        this.bt4.textf.text.tint = 0xcccccc
        this.auto_bar.addChild(this.bt4)

        this.bt5 = new BlankBtn(-210,150,"btn","btn_blank0000",'500')
        this.bt5.scale.setTo(1.2)
        this.bt5.textf.x = -24
        this.bt5.textf.text.tint = 0xcccccc
        this.auto_bar.addChild(this.bt5)

        this.bt6 = new BlankBtn(-110,150,"btn","btn_blank0000",'X')
        this.bt6.scale.setTo(1.2)
        this.bt6.textf.x = -10
        this.bt6.textf.text.tint = 0xcc0000
        this.auto_bar.addChild(this.bt6)

        this.textf = new TextField("str",24,'center')//_TextField(game,str,w,h,style,sz,border){
        this.textf.text.tint = 0xffcc33
        this.textf.y = 2
        this.textf.x = 0
        this.auto_btn.addChild(this.textf)
        this.textf.text.setText(0)
        this.textf.text.anchor.setTo(0.5)

        this.set_auto_val = function(o){
             if(o.text._text != "X"){
                slot.auto_spin_num = Number(o.text._text)
                self.update_auto_text()
                self.show_buttons();
             }else{
                slot.auto_spin_num = 0
                self.update_auto_text()
                self.show_buttons();
             }
             o.tint = 0xffffff
        }

        this.set_hover_state = function(o){
            o.tint = 0xffcc00
        }

        this.update_auto_text = function(){
            self.textf.text.setText(slot.auto_spin_num)
        }

        this.show_buttons = function(){
            //trace()
            if(active){
                active = false
                self.bt1.inputEnabled = false
                self.bt2.inputEnabled = false
                self.bt3.inputEnabled = false
                self.bt4.inputEnabled = false
                self.bt5.inputEnabled = false
                self.bt6.inputEnabled = false

                if(self.allow_auto_spin==true && self.auto_bar.x>0){
                    self.opened = true
                    TweenMax.to(self.auto_btn,0.25,{rotation:Phaser.Math.degToRad(360),startAt:{rotation:Phaser.Math.degToRad(0)}})
                    TweenMax.to(self.auto_bar,0.25,{x:0,onComplete:function(){
                        active=true
                        self.bt1.inputEnabled = true
                        self.bt2.inputEnabled = true
                        self.bt3.inputEnabled = true
                        self.bt4.inputEnabled = true
                        self.bt5.inputEnabled = true
                        self.bt6.inputEnabled = true
                    }})
                }else{
                    self.opened = false
                    TweenMax.to(self.auto_btn,0.25,{rotation:Phaser.Math.degToRad(0),startAt:{rotation:Phaser.Math.degToRad(360)}})
                    TweenMax.to(self.auto_bar,0.25,{x:660,onComplete:function(){
                        active=true
                    }})
                }
            }
        }

        Tap(this.bt1.textf,self.set_auto_val,self.set_hover_state)
        Tap(this.bt2.textf,self.set_auto_val,self.set_hover_state)
        Tap(this.bt3.textf,self.set_auto_val,self.set_hover_state)
        Tap(this.bt4.textf,self.set_auto_val,self.set_hover_state)
        Tap(this.bt5.textf,self.set_auto_val,self.set_hover_state)
        Tap(this.bt6.textf,self.set_auto_val,self.set_hover_state)

        this.bt1.textf.input.priorityID = 4
        this.bt2.textf.input.priorityID = 4
        this.bt3.textf.input.priorityID = 4
        this.bt4.textf.input.priorityID = 4
        this.bt5.textf.input.priorityID = 4
        this.bt6.textf.input.priorityID = 4

        self.input.priorityID = 800
    }
    Slot_controls.prototype = Object.create(Phaser.Sprite.prototype);
    Slot_controls.prototype.constructor = Slot_controls
    //-------------------------------------------

    //-------------------------------------------
    var BlankBtn = function _BlankBtn(x,y,img,frame,label){
        Phaser.Image.call(this, gamex, x, y,img);
        frame == null ? 0 : this.frameName = frame
        this.inputEnabled = false
        this.blendModes = 0
        this.input = new Phaser.InputHandler(this)
        this.body = null
        this.alive = false
        this.checkWorldBounds = false
        this.pivot.setTo(0.5,0.5)
        this.anchor.setTo(0.5,0.5);

        this.textf = new TextField("str",16,'center')//_TextField(game,str,w,h,style,sz,border){
        this.textf.text.tint = 0xffffff
        this.textf.y = -10
        //this.textf.text.x = 5
        this.addChild(this.textf)
        this.textf.text.setText(label)
        this.input.priorityID = 7
        this.textf.input.priorityID = 7
        return this;
    }
    BlankBtn.prototype = Object.create(Phaser.Image.prototype);
    BlankBtn.prototype.constructor = BlankBtn
    //-------------------------------------------

    //-------------------------------------------
    var Slot_menu = function _Slot_menu(x,y,slot){
        Phaser.Sprite.call(this, gamex, x, y);
        this.inputEnabled = false
        this.blendModes = 0
        this.input = new Phaser.InputHandler(this)
        this.body = null
        this.anchor.setTo(0.5,0.5);
        this.alive = false
        this.checkWorldBounds = false
        this.pivot.setTo(0.5,0.5)

        var self = this;

        this.bg = new Sprite(640,360,"bg2");
        this.addChild(this.bg);
        this.bg.tint = 0x242424;

        this.bg2 = gamex.add.graphics(0,0)
        this.bg2.beginFill(0x080808)
        this.addChild(this.bg2);
        this.bg2.drawRect(1120, 0, 160,768);

        this.bg3 = gamex.add.graphics(0,0)
        this.bg3.beginFill(0x050505)
        this.addChild(this.bg3);
        this.bg3.alpha = 0.6
        this.bg3.drawRect(20, 75, 1080,480);

        this.op1 = gamex.add.graphics(40,20)
        this.op1.beginFill(0xffffff)
        this.op1.tint = 0x999999
        this.addChild(this.op1);
        this.op1.drawRect(1100, 0, 120,120);

        this.op2 = gamex.add.graphics(40,160)
        this.op2.beginFill(0xffffff)
        this.op2.tint = 0x242424
        this.addChild(this.op2);
        this.op2.drawRect(1100, 0, 120,120);

        this.op3 = gamex.add.graphics(40,300)
        this.op3.beginFill(0xffffff)
        this.op3.tint = 0x242424
        this.addChild(this.op3);
        this.op3.drawRect(1100, 0, 120,120)

        //menu buttons
        this.info_btn = new Sprite(1200,80,"btn");
        this.addChild(this.info_btn);
        //this.info_btn.scale.setTo(1.5)
        this.info_btn.tint = 0xffffff
        this.info_btn.frameName = "btn_info0000"

        this.settings_btn = new Sprite(1200,220,"btn");
        this.addChild(this.settings_btn);
        //this.settings_btn.scale.setTo(1.5)
        this.settings_btn.tint = 0xcccccc
        this.settings_btn.frameName = "btn_settings0000"

        //close
        this.close_btn = new Sprite(40,40,"btn");
        this.addChild(this.close_btn);
        this.close_btn.tint = 0x990000
        this.close_btn.frameName = "btn_close0000"

        //info-----------------------------

        this.info_page = new Sprite(520,340)
        this.addChild(this.info_page)

        this.payline = new Sprite(0,0,'payline')
        this.info_page.addChild(this.payline)

        this.bt1 = new Slot_button_text_holder(-440,-287,'left',240)
        this.info_page.addChild(this.bt1)
        this.bt1.icon.visible = false
        this.bt1.textf.text.setText('HOW TO PLAY')

        this.bt2 = new Slot_button_text_holder(-180,-287,'left',240)
        this.info_page.addChild(this.bt2)
        this.bt2.icon.visible = false
        this.bt2.textf.text.setText('GAME RULES')

        this.bt3 = new Slot_button_text_holder(80,-287,'left',240)
        this.info_page.addChild(this.bt3)
        this.bt3.icon.visible = false
        this.bt3.textf.text.setText('PAYTABLE')

        this.bt4 = new Slot_button_text_holder(340,-287,'left',240)
        this.info_page.addChild(this.bt4)
        this.bt4.icon.visible = false
        this.bt4.textf.text.setText('PAYLINES')
        this.info_page.visible = true;

        //settings-----------------------------
        this.settings_page = new Sprite(720,340)
        this.addChild(this.settings_page)

        this.lbl1 = new Slot_button_text_holder(-680,-240,'left',240)
        this.settings_page.addChild(this.lbl1)
        this.lbl1.icon.visible = false
        this.lbl1.textf.text.setText('SOUNDS')

        this.lbl2 = new Slot_button_text_holder(-680,0,'left',240)
        this.settings_page.addChild(this.lbl2)
        this.lbl2.icon.visible = false
        this.lbl2.textf.text.setText('TURBO SPIN')

        //this.payline.blendMode = 1

        this.settings_page.visible = false;

        this.switch_tab = function(o){
            if(o == self.info_btn && self.info_page.visible == false){
                self.info_page.visible = true  
                self.settings_page.visible = false
                self.op1.tint = 0x999999
                self.op2.tint = 0x202020
            }else
            if(o == self.settings_btn && self.settings_page.visible == false){
                self.info_page.visible = false  
                self.settings_page.visible = true
                self.op1.tint = 0x202020
                self.op2.tint = 0x999999
            }
        }

        Tap(self.info_btn,self.switch_tab);

        Tap(self.settings_btn,self.switch_tab);

        //Drag(self.payline,s_drag,e_drag);

        function s_drag(o){
           
        }

        function e_drag(o){
            
            if(o.dir == 1){
                slot.info_page_id += 1
                TweenMax.to(o,0.5,{x:self.payline.width*slot.info_page_id})
            }else
            if(o.dir == -1){
                slot.info_page_id -= 1
                TweenMax.to(o,0.5,{x:self.payline.width*slot.info_page_id})
            }
        }

        //settings-----------------------------
        return this;
    }
    Slot_menu.prototype = Object.create(Phaser.Sprite.prototype);
    Slot_menu.prototype.constructor = Slot_menu

    //-------------------------------------------

    var Slot_paylines = function _Slot_paylines(x,y,slot){
        Phaser.Sprite.call(this, gamex, x, y);

        var self = this;

        var arrx = [5,4]
        var ctx_w = 18
        var clr = 'white'

        var cs_line = new Array();

        self.line_bg = new Array();

        self.line_bg[0] = new Phaser.BitmapData(gamex,"",720,360);

        self.line_bg[1] = new Phaser.BitmapData(gamex,"",720,360);
        self.line_bg[1].ctx.beginPath();
        self.line_bg[1].ctx.strokeStyle = clr;
        self.line_bg[1].ctx.lineWidth = ctx_w
//        self.line_bg[1].ctx.setLineDash(arrx);
        //self.line_bg[0].ctx.setLineDash(arrx);
        self.line_bg[1].ctx.moveTo(0,180);
        self.line_bg[1].ctx.lineTo(720, 180);
        self.line_bg[1].ctx.stroke();
        self.line_bg[1].ctx.closePath()

        cs_line[0] = new Pic(0,180,self.line_bg[1]);//dummy

        cs_line[1] = new Pic(0,180,self.line_bg[1]);
        this.addChild(cs_line[1])

        cs_line[2] = new Pic(0,0,self.line_bg[1]);
        this.addChild(cs_line[2])

        cs_line[3] = new Pic(0,360,self.line_bg[1]);
        this.addChild(cs_line[3])

        self.line_bg[2] = new Phaser.BitmapData(gamex,"",720,360);
        self.line_bg[2].ctx.beginPath();
        self.line_bg[2].ctx.strokeStyle = clr;
        self.line_bg[2].ctx.lineWidth = ctx_w
//        self.line_bg[2].ctx.setLineDash(arrx);
        self.line_bg[2].ctx.beginPath();
        self.line_bg[2].ctx.moveTo(0,0);
        self.line_bg[2].ctx.lineTo(360, 360);
        self.line_bg[2].ctx.lineTo(720, 0);
        self.line_bg[2].ctx.stroke();
        self.line_bg[2].ctx.closePath()

        cs_line[4] = new Pic(0,180,self.line_bg[2]);
        this.addChild(cs_line[4])

        cs_line[5] = new Pic(0,180,self.line_bg[2]);
        cs_line[5].scale.setTo(1,-1)
        this.addChild(cs_line[5])

        self.line_bg[3] = new Phaser.BitmapData(gamex,"s2",720,360);
        self.line_bg[3].ctx.beginPath();
        self.line_bg[3].ctx.strokeStyle = clr;
        self.line_bg[3].ctx.lineWidth = ctx_w
//        self.line_bg[3].ctx.setLineDash(arrx);
        self.line_bg[3].ctx.beginPath();
        self.line_bg[3].ctx.moveTo(0,0);
        self.line_bg[3].ctx.lineTo(180, 0);
        self.line_bg[3].ctx.lineTo(360, 180);
        self.line_bg[3].ctx.lineTo(540, 0);
        self.line_bg[3].ctx.lineTo(720, 0);
        self.line_bg[3].ctx.stroke();
        self.line_bg[3].ctx.closePath()

        cs_line[6] = new Pic(0,180,self.line_bg[3]);
        this.addChild(cs_line[6])

        cs_line[7] = new Pic(0,180,self.line_bg[3]);
        cs_line[7].scale.setTo(1,-1)
        this.addChild(cs_line[7])

        self.line_bg[4] = new Phaser.BitmapData(gamex,"s2",720,360);
        self.line_bg[4].ctx.beginPath();
        self.line_bg[4].ctx.strokeStyle = clr;
        self.line_bg[4].ctx.lineWidth = ctx_w
//        self.line_bg[4].ctx.setLineDash(arrx);
        self.line_bg[4].ctx.beginPath();
        self.line_bg[4].ctx.moveTo(0,180);
        self.line_bg[4].ctx.lineTo(180, 0);
        self.line_bg[4].ctx.lineTo(360, 0);
        self.line_bg[4].ctx.lineTo(540, 0);
        self.line_bg[4].ctx.lineTo(720, 180);
        self.line_bg[4].ctx.stroke();
        self.line_bg[4].ctx.closePath()

        cs_line[8] = new Pic(0,180,self.line_bg[4]);
        this.addChild(cs_line[8])

        cs_line[9] = new Pic(0,180,self.line_bg[4]);
        cs_line[9].scale.setTo(1,-1)
        this.addChild(cs_line[9])

        cs_line[10] = new Pic(0,0,self.line_bg[4]);
        cs_line[10].scale.setTo(1,-1)
        this.addChild(cs_line[10])

        cs_line[11] = new Pic(0,360,self.line_bg[4]);
        this.addChild(cs_line[11])

        self.line_bg[5] = new Phaser.BitmapData(gamex,"s2",720,360);
        self.line_bg[5].ctx.beginPath();
        self.line_bg[5].ctx.strokeStyle = clr;
        self.line_bg[5].ctx.lineWidth = ctx_w
//        self.line_bg[5].ctx.setLineDash(arrx);
        self.line_bg[5].ctx.beginPath();
        self.line_bg[5].ctx.moveTo(0,0);
        self.line_bg[5].ctx.lineTo(180, 180);
        self.line_bg[5].ctx.lineTo(360, 0);
        self.line_bg[5].ctx.lineTo(540, 180);
        self.line_bg[5].ctx.lineTo(720, 0);
        self.line_bg[5].ctx.stroke();
        self.line_bg[5].ctx.closePath()

        cs_line[12] = new Pic(0,180,self.line_bg[5]);
        this.addChild(cs_line[12])

        cs_line[13] = new Pic(0,180,self.line_bg[5]);
        cs_line[13].scale.setTo(1,-1)
        this.addChild(cs_line[13])

        cs_line[14] = new Pic(0,0,self.line_bg[5]);
        cs_line[14].scale.setTo(1,-1)
        this.addChild(cs_line[14])

        cs_line[15] = new Pic(0,360,self.line_bg[5]);
        this.addChild(cs_line[15])

        self.line_bg[6] = new Phaser.BitmapData(gamex,"s2",720,360);
        self.line_bg[6].ctx.beginPath();
        self.line_bg[6].ctx.strokeStyle = clr;
        self.line_bg[6].ctx.lineWidth = ctx_w
//        self.line_bg[6].ctx.setLineDash(arrx);
        self.line_bg[6].ctx.beginPath();
        self.line_bg[6].ctx.moveTo(0,0);
        self.line_bg[6].ctx.lineTo(180, 0);
        self.line_bg[6].ctx.lineTo(360, 180);
        self.line_bg[6].ctx.lineTo(540, 0);
        self.line_bg[6].ctx.lineTo(720, 0);
        self.line_bg[6].ctx.stroke();
        self.line_bg[6].ctx.closePath()

        cs_line[16] = new Pic(0,0,self.line_bg[6]);
        cs_line[16].scale.setTo(1,-1)
        this.addChild(cs_line[16])

        cs_line[17] = new Pic(0,360,self.line_bg[6]);
        this.addChild(cs_line[17])

        self.line_bg[7] = new Phaser.BitmapData(gamex,"s2",720,360);
        self.line_bg[7].ctx.beginPath();
        self.line_bg[7].ctx.strokeStyle = clr;
        self.line_bg[7].ctx.lineWidth = ctx_w
//        self.line_bg[7].ctx.setLineDash(arrx);
        self.line_bg[7].ctx.beginPath();
        self.line_bg[7].ctx.moveTo(0,0);
        self.line_bg[7].ctx.lineTo(180, 360);
        self.line_bg[7].ctx.lineTo(360, 0);
        self.line_bg[7].ctx.lineTo(540, 360);
        self.line_bg[7].ctx.lineTo(720, 0);
        self.line_bg[7].ctx.stroke();
        self.line_bg[7].ctx.closePath()

        cs_line[18] = new Pic(0,180,self.line_bg[7]);
        this.addChild(cs_line[18])

        cs_line[19] = new Pic(0,180,self.line_bg[7]);
        cs_line[19].scale.setTo(1,-1)
        this.addChild(cs_line[19])

        self.line_bg[8] = new Phaser.BitmapData(gamex,"s2",720,360);
        self.line_bg[8].ctx.beginPath();
        self.line_bg[8].ctx.strokeStyle = clr;
        self.line_bg[8].ctx.lineWidth = ctx_w
//        self.line_bg[8].ctx.setLineDash(arrx);
        self.line_bg[8].ctx.beginPath();
        self.line_bg[8].ctx.moveTo(0,180);
        self.line_bg[8].ctx.lineTo(180, 360);
        self.line_bg[8].ctx.lineTo(360, 0);
        self.line_bg[8].ctx.lineTo(540, 360);
        self.line_bg[8].ctx.lineTo(720, 180);
        self.line_bg[8].ctx.stroke();
        self.line_bg[8].ctx.closePath()

        cs_line[20] = new Pic(0,180,self.line_bg[8]);
        cs_line[20].scale.setTo(1,-1)
        this.addChild(cs_line[20])

        cs_line[21] = new Pic(0,180,self.line_bg[8]);
        cs_line[21].scale.setTo(1,1)
        this.addChild(cs_line[21])

        self.line_bg[9] = new Phaser.BitmapData(gamex,"s2",720,360);
        self.line_bg[9].ctx.beginPath();
        self.line_bg[9].ctx.strokeStyle = clr;
        self.line_bg[9].ctx.lineWidth = ctx_w
//        self.line_bg[9].ctx.setLineDash(arrx);
        self.line_bg[9].ctx.beginPath();
        self.line_bg[9].ctx.moveTo(0,0);
        self.line_bg[9].ctx.lineTo(180, 0);
        self.line_bg[9].ctx.lineTo(360, 360);
        self.line_bg[9].ctx.lineTo(540, 0);
        self.line_bg[9].ctx.lineTo(720, 0);
        self.line_bg[9].ctx.stroke();
        self.line_bg[9].ctx.closePath()

        cs_line[22] = new Pic(0,180,self.line_bg[9]);
        cs_line[22].scale.setTo(1,1)
        this.addChild(cs_line[22])

        cs_line[23] = new Pic(0,180,self.line_bg[9]);
        cs_line[23].scale.setTo(1,-1)
        this.addChild(cs_line[23])

        self.line_bg[10] = new Phaser.BitmapData(gamex,"s2",720,360);
        self.line_bg[10].ctx.beginPath();
        self.line_bg[10].ctx.strokeStyle = clr;
        self.line_bg[10].ctx.lineWidth = ctx_w
//        self.line_bg[10].ctx.setLineDash(arrx);
        self.line_bg[10].ctx.beginPath();
        self.line_bg[10].ctx.moveTo(0,0);
        self.line_bg[10].ctx.lineTo(180, 360);
        self.line_bg[10].ctx.lineTo(360, 360);
        self.line_bg[10].ctx.lineTo(540, 360);
        self.line_bg[10].ctx.lineTo(720, 0);
        self.line_bg[10].ctx.stroke();
        self.line_bg[10].ctx.closePath()

        cs_line[24] = new Pic(0,180,self.line_bg[10]);
        cs_line[24].scale.setTo(1,1)
        this.addChild(cs_line[24])

        cs_line[25] = new Pic(0,180,self.line_bg[10]);
        cs_line[25].scale.setTo(1,-1)
        this.addChild(cs_line[25])

        self.line_bg[11] = new Phaser.BitmapData(gamex,"s2",720,360);
        self.line_bg[11].ctx.beginPath();
        self.line_bg[11].ctx.strokeStyle = clr;
        self.line_bg[11].ctx.lineWidth = ctx_w
//        self.line_bg[11].ctx.setLineDash(arrx);
        self.line_bg[11].ctx.beginPath();
        self.line_bg[11].ctx.moveTo(0,360);
        self.line_bg[11].ctx.lineTo(180, 0);
        self.line_bg[11].ctx.lineTo(360, 180);
        self.line_bg[11].ctx.lineTo(540, 0);
        self.line_bg[11].ctx.lineTo(720, 360);
        self.line_bg[11].ctx.stroke();
        self.line_bg[11].ctx.closePath()

        cs_line[26] = new Pic(0,180,self.line_bg[11]);
        cs_line[26].scale.setTo(1,1)
        this.addChild(cs_line[26])

        cs_line[27] = new Pic(0,180,self.line_bg[11]);
        cs_line[27].scale.setTo(1,-1)
        this.addChild(cs_line[27])

        self.line_bg[12] = new Phaser.BitmapData(gamex,"s2",720,360);
        self.line_bg[12].ctx.beginPath();
        self.line_bg[12].ctx.strokeStyle = clr;
        self.line_bg[12].ctx.lineWidth = ctx_w
//        self.line_bg[12].ctx.setLineDash(arrx);
        self.line_bg[12].ctx.beginPath();
        self.line_bg[12].ctx.moveTo(0,0);
        self.line_bg[12].ctx.lineTo(180, 0);
        self.line_bg[12].ctx.lineTo(360, 180);
        self.line_bg[12].ctx.lineTo(540, 360);
        self.line_bg[12].ctx.lineTo(720, 360);
        self.line_bg[12].ctx.stroke();
        self.line_bg[12].ctx.closePath()

        cs_line[28] = new Pic(0,180,self.line_bg[12]);
        cs_line[28].scale.setTo(1,1)
        this.addChild(cs_line[28])

        cs_line[29] = new Pic(0,180,self.line_bg[12]);
        cs_line[29].scale.setTo(1,-1)
        this.addChild(cs_line[29])

        self.line_bg[13] = new Phaser.BitmapData(gamex,"s2",720,360);
        self.line_bg[13].ctx.beginPath();
        self.line_bg[13].ctx.strokeStyle = clr;
        self.line_bg[13].ctx.lineWidth = ctx_w
//        self.line_bg[13].ctx.setLineDash(arrx);
        self.line_bg[13].ctx.beginPath();
        self.line_bg[13].ctx.moveTo(0,180);
        self.line_bg[13].ctx.lineTo(180, 0);
        self.line_bg[13].ctx.lineTo(360, 180);
        self.line_bg[13].ctx.lineTo(540, 360);
        self.line_bg[13].ctx.lineTo(720, 180);
        self.line_bg[13].ctx.stroke();
        self.line_bg[13].ctx.closePath()

        cs_line[30] = new Pic(0,180,self.line_bg[13]);
        cs_line[30].scale.setTo(1,1)
        this.addChild(cs_line[30])

        //all lines
        this.line = gamex.add.graphics(0,0)
        this.addChild(this.line);

        //this.line.alpha = 0.25

        this.hide_line_bg = function(){ 
            for(i=1;i<31;i++){
                cs_line[i].visible = false
            }
        }

        this.hide_line_bg();

        this.draw_lines = function _draw_lines(arr){
            this.arrx = [10,10]
            self.line.lineStyle(5, 0x33ccff);

            //self.hide_line_bg();
            if(arr.indexOf(1)>-1){
            //line1
                this.line.moveTo(-360,180);
                this.line.lineTo(360, 180);
                cs_line[1].visible = true
                TweenMax.to(cs_line[1],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(2)>-1){
            //line2
                this.line.moveTo(-360,0);
                this.line.lineTo(360, 0);
                cs_line[2].visible = true
                TweenMax.to(cs_line[2],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(3)>-1){
            //line3
                this.line.moveTo(-360,360);
                this.line.lineTo(360, 360);
                cs_line[3].visible = true
                TweenMax.to(cs_line[3],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(4)>-1){
            //line4
                this.line.moveTo(-360,0);
                this.line.lineTo(0, 360);
                this.line.lineTo(360, 0);
                cs_line[4].visible = true
                TweenMax.to(cs_line[4],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(5)>-1){
           //line5
                this.line.moveTo(-360,360);
                this.line.lineTo(0, 0);
                this.line.lineTo(360, 360);
                cs_line[5].visible = true
                TweenMax.to(cs_line[5],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(6)>-1){
            //line6
                this.line.moveTo(-360,0);
                this.line.lineTo(-180, 0);
                this.line.lineTo(0, 180);
                this.line.lineTo(180, 0);
                this.line.lineTo(360,0); 
                cs_line[6].visible = true
                TweenMax.to(cs_line[6],0.25,{alpha:0,repeat:3,yoyo:true})           
            }
            if(arr.indexOf(7)>-1){
            //line7
                this.line.moveTo(-360,360);
                this.line.lineTo(-180, 360);
                this.line.lineTo(0, 180);
                this.line.lineTo(180, 360);
                this.line.lineTo(360,360);   
                cs_line[7].visible = true
                TweenMax.to(cs_line[7],0.25,{alpha:0,repeat:3,yoyo:true})         
            }
            if(arr.indexOf(8)>-1){
            //line8
                this.line.moveTo(-360,180);
                this.line.lineTo(-180, 0);
                this.line.lineTo(0, 0);
                this.line.lineTo(180, 0);
                this.line.lineTo(360,180);
                cs_line[8].visible = true
                TweenMax.to(cs_line[8],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(9)>-1){
            //line9
                this.line.moveTo(-360,180);
                this.line.lineTo(-180, 360);
                this.line.lineTo(0, 360);
                this.line.lineTo(180, 360);
                this.line.lineTo(360,180);
                cs_line[9].visible = true
                TweenMax.to(cs_line[9],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(10)>-1){
            //line10
                this.line.moveTo(-360,0);
                this.line.lineTo(-360, 0);
                this.line.lineTo(-180, 180);
                this.line.lineTo(180, 180);
                this.line.lineTo(360,0);
                cs_line[10].visible = true
                TweenMax.to(cs_line[10],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(11)>-1){
            //line11
                this.line.moveTo(-360,360);
                this.line.lineTo(-180, 180);
                this.line.lineTo(0, 180);
                this.line.lineTo(180, 180);
                this.line.lineTo(360,360);
                cs_line[11].visible = true
                TweenMax.to(cs_line[11],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(12)>-1){
            //line12
                this.line.moveTo(-360,0);
                this.line.lineTo(-180, 180);
                this.line.lineTo(0, 0);
                this.line.lineTo(180,180);
                this.line.lineTo(360,0);
                cs_line[12].visible = true
                TweenMax.to(cs_line[12],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(13)>-1){
            //line13
                this.line.moveTo(-360,360);
                this.line.lineTo(-180, 180);
                this.line.lineTo(0, 360);
                this.line.lineTo(180,180);
                this.line.lineTo(360,360);
                cs_line[13].visible = true
                TweenMax.to(cs_line[13],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(14)>-1){
            //line14
                this.line.moveTo(-360,180);
                this.line.lineTo(-180, 0);
                this.line.lineTo(0, 180);
                this.line.lineTo(180,0);
                this.line.lineTo(360,180);
                cs_line[14].visible = true
                TweenMax.to(cs_line[14],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(15)>-1){
            //line15
                this.line.moveTo(-360,180);
                this.line.lineTo(-180, 360);
                this.line.lineTo(0, 180);
                this.line.lineTo(180,360);
                this.line.lineTo(360,180);
                cs_line[15].visible = true
                TweenMax.to(cs_line[15],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(16)>-1){
            //line16
                this.line.moveTo(-360,180);
                this.line.lineTo(-180, 180);
                this.line.lineTo(0, 0);
                this.line.lineTo(180,180);
                this.line.lineTo(360,180);
                cs_line[16].visible = true
                TweenMax.to(cs_line[16],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(17)>-1){
            //line17
                this.line.moveTo(-360,180);
                this.line.lineTo(-180, 180);
                this.line.lineTo(0, 360);
                this.line.lineTo(180,180);
                this.line.lineTo(360,180);
                cs_line[17].visible = true
                TweenMax.to(cs_line[17],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(18)>-1){
            //line18
                this.line.moveTo(-360,0);
                this.line.lineTo(-180, 360);
                this.line.lineTo(0, 0);
                this.line.lineTo(180,360);
                this.line.lineTo(360,0);
                cs_line[18].visible = true
                TweenMax.to(cs_line[18],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(19)>-1){
            //line19
                this.line.moveTo(-360,360);
                this.line.lineTo(-180, 0);
                this.line.lineTo(0, 360);
                this.line.lineTo(180,0);
                this.line.lineTo(360,360);
                cs_line[19].visible = true
                TweenMax.to(cs_line[19],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(20)>-1){
            //line20
                this.line.moveTo(-360,180);
                this.line.lineTo(-180, 0);
                this.line.lineTo(0, 360);
                this.line.lineTo(180,0);
                this.line.lineTo(360,180);
                cs_line[20].visible = true
                TweenMax.to(cs_line[20],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(21)>-1){
            //line21
                this.line.moveTo(-360,180);
                this.line.lineTo(-180, 360);
                this.line.lineTo(0, 0);
                this.line.lineTo(180,360);
                this.line.lineTo(360,180);
                cs_line[21].visible = true
                TweenMax.to(cs_line[21],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(22)>-1){
           //line22
                this.line.moveTo(-360,0);
                this.line.lineTo(-180, 0);
                this.line.lineTo(0, 360);
                this.line.lineTo(180,0);
                this.line.lineTo(360,0);
                cs_line[22].visible = true
                TweenMax.to(cs_line[22],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(23)>-1){
            //line23
                this.line.moveTo(-360,360);
                this.line.lineTo(-180, 360);
                this.line.lineTo(0, 0);
                this.line.lineTo(180,360);
                this.line.lineTo(360,360);
                cs_line[23].visible = true
                TweenMax.to(cs_line[23],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(24)>-1){
            //line24
                this.line.moveTo(-360,0);
                this.line.lineTo(-180, 360);
                this.line.lineTo(0, 360);
                this.line.lineTo(180,360);
                this.line.lineTo(360,0);
                cs_line[24].visible = true
                TweenMax.to(cs_line[24],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(25)>-1){
            //line25
                this.line.moveTo(-360,360);
                this.line.lineTo(-180, 0);
                this.line.lineTo(0, 0);
                this.line.lineTo(180,0);
                this.line.lineTo(360,360);
                cs_line[25].visible = true
                TweenMax.to(cs_line[25],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(26)>-1){
            //line26
                this.line.moveTo(-360,360);
                this.line.lineTo(-180, 0);
                this.line.lineTo(0, 180);
                this.line.lineTo(180,0);
                this.line.lineTo(360,360);
                cs_line[26].visible = true
                TweenMax.to(cs_line[26],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(27)>-1){
            //line27
                this.line.moveTo(-360,0);
                this.line.lineTo(-180, 360);
                this.line.lineTo(0, 180);
                this.line.lineTo(180,360);
                this.line.lineTo(360,0);
                cs_line[27].visible = true
                TweenMax.to(cs_line[27],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(28)>-1){
            //line28
                this.line.moveTo(-360,0);
                this.line.lineTo(-180, 0);
                this.line.lineTo(0, 180);
                this.line.lineTo(180,360);
                this.line.lineTo(360,360);
                cs_line[28].visible = true
                TweenMax.to(cs_line[28],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(29)>-1){
            //line29
                this.line.moveTo(-360,360);
                this.line.lineTo(-180, 360);
                this.line.lineTo(0, 180);
                this.line.lineTo(180,0);
                this.line.lineTo(360,0);
                cs_line[29].visible = true
                TweenMax.to(cs_line[29],0.25,{alpha:0,repeat:3,yoyo:true})
            }
            if(arr.indexOf(30)>-1){
            //line30
                this.line.moveTo(-360,180);
                this.line.lineTo(-180, 0);
                this.line.lineTo(0, 180);
                this.line.lineTo(180,360);
                this.line.lineTo(360,180);
                cs_line[30].visible = true
                TweenMax.to(cs_line[30],0.25,{alpha:0,repeat:3,yoyo:true})
            }
        }//end

        return this;
    }
    Slot_paylines.prototype = Object.create(Phaser.Sprite.prototype);
    Slot_paylines.prototype.constructor = Slot_paylines

    //-------------------------------------------
    
    var Slot_Gamble_Game = function _Slot_Gamble_Game(x,y,slot){
        Phaser.Sprite.call(this, gamex, x, y);
        this.inputEnabled = false
        this.blendModes = 0
        this.input = new Phaser.InputHandler(this)
        this.input.priorityID = 0
        this.body = null
        this.anchor.setTo(0.5,0.5);
        
        var self = this;
                                       
        /*this.bg = gamex.add.graphics(0,0)
        this.addChild(this.bg);
        this.bg.beginFill(0x202020)
        this.bg.lineStyle(4,0xff0000)
        this.bg.drawRoundedRect(-450, -90, 900,535)

        this.bmp = new Phaser.BitmapData(100,100)
        this.key = this.bmp*/

        //this.line.clear();
        return this;
    }
    Slot_Gamble_Game.prototype = Object.create(Phaser.Sprite.prototype);
    Slot_Gamble_Game.prototype.constructor = Slot_Gamble_Game

    //-------------------------------------------

    var Slot_free_opt_btn = function _Slot_Free_Flier(x,y,slot){
        Phaser.Sprite.call(this, gamex, x, y,"free_spin_option");

        var self = this;

        this.inputEnabled = false
        this.blendModes = 0
        this.input = new Phaser.InputHandler(this)
        this.input.priorityID = 0
        this.body = null
        this.anchor.setTo(0.5,0.5);
        this.input.priorityID = 0
        this.input.pixelPerfectOver = false;

        return this;
    }
    Slot_free_opt_btn.prototype = Object.create(Phaser.Sprite.prototype);
    Slot_free_opt_btn.prototype.constructor = Slot_free_opt_btn

    //----------------------------------------------------------------
    var Slot_Free_Flier = function _Slot_Free_Flier(x,y,slot){
        Phaser.Sprite.call(this, gamex, x, y);

        this.inputEnabled = false
        this.blendModes = 0
        this.input = new Phaser.InputHandler(this)
        this.input.priorityID = 0
        this.body = null
        this.anchor.setTo(0.5,0.5);

        this.input.pixelPerfectClick = false
        var my_slot = slot

        var self = this;
                                       
        this.bg = gamex.add.graphics(0,0)
        this.addChild(this.bg);
        this.bg.beginFill(0x202020)
        this.bg.lineStyle(4,0xff0000)
        this.bg.drawRoundedRect(-460, -110, 920,560)
        this.bg.alpha = 1

        this.f1 = new Slot_free_opt_btn(-320,170)
        this.f1.frameName = "f10000"
        this.addChild(this.f1);

        this.f2 = new Slot_free_opt_btn(0,170)
        this.f2.frameName = "f20000"
        this.addChild(this.f2);

        this.f3 = new Slot_free_opt_btn(320,170)
        this.f3.frameName = "f30000"
        this.addChild(this.f3);


        this.tap_opt = function(o){
            TweenMax.to(o.scale,0.05,{x:0.95,y:0.98,repeat:1,yoyo:true})
            if(o== self.f1){
                slot.be.request_free_option(slot,0)
            }else
            if(o== self.f2){
                slot.be.request_free_option(slot,1)
            }else
            if(o== self.f3){
                slot.be.request_free_option(slot,2)
            } 
        }

        Tap(this.f1,self.tap_opt);
        Tap(this.f2,self.tap_opt);
        Tap(this.f3,self.tap_opt);

        this.f1.input.priorityID = 1
        this.f2.input.priorityID = 1
        this.f3.input.priorityID = 1

        this.f3.input.pixelPerfectOver = false

        return this;
    }
    Slot_Free_Flier.prototype = Object.create(Phaser.Sprite.prototype);
    Slot_Free_Flier.prototype.constructor = Slot_Free_Flier

    //-------------------------------------------

    var Slot_win_holder_mini = function _Slot_win_holder_mini(x,y,slot){
            Phaser.Image.call(this, gamex, x, y);
            this.input = new Phaser.InputHandler(this)
            this.inputEnabled = false
            this.blendModes = 0
            this.body = null
            this.anchor.setTo(0.5,0.5);
            this.alive = false
            this.checkWorldBounds = false
            this.pivot.setTo(0.5,0.5)

            this.bg = gamex.add.graphics(0,-20)
            this.addChild(this.bg);
            this.bg.beginFill(0x202020)
            this.bg.lineStyle(4,0xffffff)
            this.bg.drawRoundedRect(-90, -30, 180,40)
            this.bg.alpha = 0.95

            this.textf = new TextField("1,000",30,0,-28,'center')///__TextField(str,sz,x,y,algn){
            this.textf.text.tint = 0xffdd00
            this.textf.anchor.setTo(0.5,0.5)
            this.addChild(this.textf)
            return this;
    }
    Slot_win_holder_mini.prototype = Object.create(Phaser.Image.prototype);
    Slot_win_holder_mini.prototype.constructor = Slot_win_holder_mini

    //-------------------------------------------

    //-------------------------------------------

    //-------------------------------------------

    //-------------------------------------------



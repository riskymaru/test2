
ChoiceSprite = function(_game, _x, _y)
{
	Phaser.Sprite.call(this, _game, _x, _y,'off_selection_bg');
	//this.tint = 0x00ffff;

/*
	this.choice0 = this.addChild(_game.add.sprite(0,0,'choice_select'));
	this.choice1 = this.addChild(_game.add.sprite(0,0,'choice_correct'));
	this.choice1.alpha =0;
	this.choice2 = this.addChild(_game.add.sprite(0,0,'choice_wrong'));
	this.choice2.alpha = 0;
	this.choice3 = this.addChild(_game.add.sprite(0,0,'choice_made'));
	this.choice3.alpha = 0;
*/
	this.blendMode = PIXI.blendModes.SCREEN;


	this.bg2 = this.addChild(_game.add.sprite(0,0,'off_selection_bg2'));
	this.bg2.blendMode = PIXI.blendModes.SCREEN;


	//this.bg = this.addChild(_game.add.sprite(0,0,'off_selection_bg'));
	//this.bg.blendMode = PIXI.blendModes.SCREEN;
	//this.bg.scale.set(0.9);
	this.note_continue = this.addChild(_game.add.sprite(0,0,'off_note'));
	this.note_continue.blendMode = PIXI.blendModes.SCREEN;
	this.note_continue.visible = false;
	this.note_end = this.addChild(_game.add.sprite(0,0,'off_note_end'));
	this.note_end.blendMode = PIXI.blendModes.SCREEN;
	this.note_end.visible = false;
	this.cover = this.addChild(_game.add.sprite(0,0,'off_cover'));
	//this.cover.blendMode = PIXI.blendModes.SCREEN;

	this.anchor.setTo(0.5,0.5);
	this.bg2.anchor.setTo(0.5,0.5);
	//this.bg.anchor.setTo(0.5,0.5);
	this.note_continue.anchor.setTo(0.5,0.5);
	this.note_end.anchor.setTo(0.5,0.5);
	this.cover.anchor.setTo(0.5,0.5);


	//this.bg2.tint = 0x00ffff;
	//this.bg.tint = 0x00ffff;

	//this.note_cover = this.addChild(_game.add.sprite(0,0,'off_cover'));
	//this.note_cover.anchor.setTo(0.5,0.5);
	
	

	
};


ChoiceSprite.prototype = Object.create(Phaser.Sprite.prototype);
ChoiceSprite.prototype.constructor = ChoiceSprite;

ChoiceSprite.prototype.resetFace = function()
{
	this.tint = 0x0;
	this.bg2.tint = 0x0;

	this.note_continue.visible = false;
	this.note_end.visible = false;

	this.cover.alpha = 1;
	this.cover.scale.setTo(1);
	this.note_continue.scale.setTo(1);
	this.note_continue.alpha = 1;
};

ChoiceSprite.prototype.switchFace = function(faceNumber)
{
	switch(faceNumber)
	{
		case 0:   //cover
			/*
			this.choice1.alpha = 0;
			this.choice2.alpha = 0;
			this.choice3.alpha = 0;*/

			TweenMax.to(this.cover, 0.25,{alpha:1});
			

		break;

		case 1:   //correct
		/*
			this.choice1.alpha = 1;
			this.choice2.alpha = 0;
			this.choice3.alpha = 0;*/

			this.tint = 0x00ffff;
			this.bg2.tint = 0x00ffff;

			this.note_continue.visible = true;
			this.note_end.visible = false;
			TweenMax.to(this.cover, 0.5,{alpha:0});
			TweenMax.to(this.cover.scale, 0.3,{x:0.1, y:0.1});
			TweenMax.to(this.note_continue.scale, 0.25, {x:2, y:2, repeat:1, yoyo:true, delay:0.25});
			TweenMax.to(this.note_continue, 0, {delay:0.75, alpha:0});

		break;

		case 2:   //wrong\
		/*
			this.choice1.alpha = 0;
			this.choice2.alpha = 1;
			this.choice3.alpha = 0;*/

			this.tint = 0xffcc11;
			this.bg2.tint = 0xffcc11;

			this.note_continue.visible = false;
			this.note_end.visible = true;
			TweenMax.to(this.cover, 0.5,{alpha:0});
			TweenMax.to(this.note_end, 0.25, {scaleX:2, scaleY:2, repeat:1, yoyo:true, delay:0.25});
			TweenMax.to(this.note_end, 0, {delay:0.75, alpha:0});
		break;

		case 3:

			this.note_continue.visible = true;
			this.note_end.visible = false;
			TweenMax.to(this.cover, 0.5,{alpha:0});
			TweenMax.to(this.note_continue.scale, 0.25, {x:2, y:2, repeat:1, yoyo:true, delay:0.25});
			//TweenMax.to(this.note_continue, 0, {delay:0.75, alpha:0});
		break;

	}
};


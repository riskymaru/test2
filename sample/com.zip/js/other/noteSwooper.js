NoteSwooper = function(_game, _x, _y)
{
	Phaser.Sprite.call(this, _game, _x, _y,createRectangleBitmapData(0,0,"#303030"));
	this.anchor.setTo(0.5,0.5);

	this.blendMode = PIXI.blendModes.SCREEN;

	this.routePoints = [{x:0,y:0},{x:0,y:0}];
	
	this.alpha =0;

	this.note_continue = this.addChild(_game.add.sprite(0,0,'off_note'));
	this.note_continue.blendMode = PIXI.blendModes.SCREEN;
	this.note_continue.anchor.setTo(0.5,0.5);
	this.note_continue.visible = true;
	this.note_end = this.addChild(_game.add.sprite(0,0,'off_note_end'));
	this.note_end.blendMode = PIXI.blendModes.SCREEN;
	this.note_end.visible = false;
	this.note_end.anchor.setTo(0.5,0.5);


	//this.toCall = null;
};


NoteSwooper.prototype = Object.create(Phaser.Sprite.prototype);
NoteSwooper.prototype.constructor = NoteSwooper;

NoteSwooper.prototype.setDisplay = function(faceNumber)
{
	
	switch(faceNumber)
	{
		case 0:
			this.note_continue.visible = true;
			this.note_end.visible = false;

		break;

		case 1:
			this.note_continue.visible = false;
			this.note_end.visible = true;

		break;

	}
}

NoteSwooper.prototype.setPointA = function(_x,_y)
{
	this.routePoints[0].x = _x;
	this.routePoints[0].y = _y;
};

NoteSwooper.prototype.setPointB = function(_x,_y)
{
	this.routePoints[1].x = _x;
	this.routePoints[1].y = _y;
};

NoteSwooper.prototype.getPointB = function()
{
	return {x:this.routePoints[1].x, y:this.routePoints[1].y};
};

NoteSwooper.prototype.reachedGoal = function()
{
	console.log('note reached goal');
};

NoteSwooper.prototype.startMovement= function()
{
	//call in note (this)
	this.scale.x = 1;
	this.scale.y = 1;
	//this.alpha = 1;
	this.x = this.routePoints[0].x;
	this.y = this.routePoints[0].y;


	//tween movement from A to B then call function
	//simple tween for now	
	//this.actionControl.restart();
	//TweenMax.to(this, 5, {x:this.routePoints[1].x, y:this.routePoints[1].y});

};

NoteSwooper.prototype.setPointBAndStart = function(bx,by)
{
	//due to the tween 'this' issue im placing all heavy movement in the base sprite so this wont be used

	//console.log(this.routePoints);	
	this.setPointB(bx,by);

	this.startMovement();
	//this.toCall = callfunc;
};

NoteSwooper.prototype.goalAchievedExit = function()
{
	TweenMax.to(this.scale, 0.5,{x:0.1, y:0.1});
	TweenMax.to(this, 0.5,{alpha:0});


};
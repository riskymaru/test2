
WarpWall = function(_game, _x, _y)
{
	Phaser.Sprite.call(this, _game, _x, _y,'off_stage_light');
	this.anchor.setTo(0.5, 0.5);

	this.blendMode = PIXI.blendModes.SCREEN;
	
	this.scale.x = 0.1;	

	this.actionTween = new TimelineLite();
	this.actionTween.to(this.scale, 0.5, {x:1, repeat:-1, yoyo:true});
	this.actionTween.paused(true);
};


WarpWall.prototype = Object.create(Phaser.Sprite.prototype);
WarpWall.prototype.constructor = WarpWall;

WarpWall.prototype.playAnimation = function()
{
	this.actionTween.paused(false);
};

WarpWall.prototype.stopAnimation = function()
{
	this.actionTween.paused(true);
};

PowerSprite = function(_game, _x, _y)
{
	Phaser.Sprite.call(this, _game, _x, _y,createRectangleBitmapData(0,0,"#303030"));

	this.choice0 = this.addChild(_game.add.sprite(0,0,'off_music_set'));
	this.choice0.blendMode = PIXI.blendModes.SCREEN;
	this.choice0.anchor.setTo(0.5,0.5);
	this.choice0.alpha =0;
	this.choice1 = this.addChild(_game.add.sprite(0,0,'off_note'));
	this.choice1.alpha =0;
	this.choice1.anchor.setTo(0.5,0.5);

	this.effectBG = this.addChild(_game.add.sprite(0,0,'off_selection_bg'));
	this.effectBG.blendMode = PIXI.blendModes.SCREEN;
	this.effectBG.anchor.setTo(0.5,0.5);
	this.effectBG.alpha = 0;
};


PowerSprite.prototype = Object.create(Phaser.Sprite.prototype);
PowerSprite.prototype.constructor = PowerSprite;


PowerSprite.prototype.switchFace = function(faceNumber)
{
	switch(faceNumber)
	{
		case 0:
			//this.choice1.alpha = 0;
			this.choice0.alpha = 0;

		break;

		case 1:
			//this.choice1.alpha = 1;
			this.choice0.scale.tint = "#ffffff";
			this.effectBG.alpha = 1;
			TweenMax.to(this.effectBG.scale, 0.4, {x:3, y:3});
			TweenMax.to(this.effectBG, 0.6, {alpha:0});
			TweenMax.to(this.choice0, 1,{alpha:1});

		break;

		case 2:
		
		//this.choice1.alpha = 1;
			this.effectBG.alpha = 1;
			this.choice0.scale.tint = "#ff0000";
			TweenMax.to(this.effectBG.scale, 0.4, {x:3, y:3});
			TweenMax.to(this.effectBG, 0.6, {alpha:0});
			TweenMax.to(this.choice0, 1,{alpha:1});

		break;


	}
};

PowerSprite.prototype.noteCall = function(_x,_y)
{
	this.choice1.x = this.x - _x;
	this.choice1.y = this.y - _y;
};


GameSpriteNoServ2Variables = new Object();
var MockServerSig = new Phaser.Signal();

GameSpriteNoServ2 = function(_game, _parent)
{
	//this.exitSignal = exitSig;

	this.game = _game;
	this._parent = _parent;

	GameSpriteNoServ2Variables.me = this;
	
	Phaser.Sprite.call(this, _game, 0, 0,createRectangleBitmapData(0,0,"#303030"));
	
	//this.game.add.existing(this); 

	this.isRunning = false;

	this.actionLine = new TimelineLite();


	
	this.bg = this.game.add.sprite(0,0,'off_bg');
	this.addChild(this.bg);


	this.scales = this.game.add.sprite(0,0,'off_music_sheet');
	this.scales.blendMode = PIXI.blendModes.SCREEN;
	this.scales.x = 30;
	this.scales.y = 20;
	this.addChild(this.scales);

	this.warpingWall = new WarpWall(_game, 640, 300);
	this.addChild(this.warpingWall);

	this.choiceList = []; //may remove this later but placing it here to make selecting easier
	
	//this is the selection buttons
	this.choice0 = new ChoiceSprite(_game, 0,0);
	this.choice1 = new ChoiceSprite(_game, 0,-this.choice0.height -20);
	this.choice2 = new ChoiceSprite(_game, -this.choice0.width -10, -this.choice0.height*0.5 +20);
	this.choice3 = new ChoiceSprite(_game, this.choice0.width +10, -this.choice0.height*0.5 +20);
	this.choice4 = new ChoiceSprite(_game, -this.choice0.width *0.5 -10, this.choice0.height);
	this.choice5 = new ChoiceSprite(_game, this.choice0.width *0.5 +10, this.choice0.height);
	

	this.choice0.inputEnabled = true;
	this.choice1.inputEnabled = true;
	this.choice2.inputEnabled = true;
	this.choice3.inputEnabled = true;
	this.choice4.inputEnabled = true;
	this.choice5.inputEnabled = true;
	

	this.choice0.name = 'choice_0';
	this.choice1.name = 'choice_1';
	this.choice2.name = 'choice_2';
	this.choice3.name = 'choice_3';
	this.choice4.name = 'choice_4';
	this.choice5.name = 'choice_5';
	
	this.addChild(this.choice0);
	this.addChild(this.choice1);
	this.addChild(this.choice2);
	this.addChild(this.choice3);
	this.addChild(this.choice4);
	this.addChild(this.choice5);
	
	this.choiceList = [this.choice0,this.choice1,this.choice2,this.choice3,this.choice4,this.choice5
	
	]; 

	this.choiceGroup = this.game.add.group(); 
	this.choiceGroup.add(this.choice0);
	this.choiceGroup.add(this.choice1);
	this.choiceGroup.add(this.choice2);
	this.choiceGroup.add(this.choice3);
	this.choiceGroup.add(this.choice4);
	this.choiceGroup.add(this.choice5);
	
	this.choiceGroup.x = 640;
	this.choiceGroup.y = 280;
	this.choiceGroup.scale.setTo(0.8,0.8);



	//this will be the bonus recommendation buttons
	this.initialPlayMultiplier = new PowerSprite(_game, this.scales.x +160, this.scales.y+60);

	this.multiplier0 = new PowerSprite(_game, this.scales.x + 320,this.scales.y+60);
	this.multiplier1 = new PowerSprite(_game, this.multiplier0.x + 160,this.scales.y+60);
	this.multiplier2 = new PowerSprite(_game, this.multiplier1.x + 160,this.scales.y+60);
	this.multiplier3 = new PowerSprite(_game, this.multiplier2.x + 160,this.scales.y+60);
	this.multiplier4 = new PowerSprite(_game, this.multiplier3.x + 160,this.scales.y+60);
	this.multiplier5 = new PowerSprite(_game, this.multiplier4.x + 160,this.scales.y+60);

	this.multiplier0.name = 'mult_0';
	this.multiplier1.name = 'mult_1';
	this.multiplier2.name = 'mult_2';
	this.multiplier3.name = 'mult_3';
	this.multiplier4.name = 'mult_4';
	this.multiplier5.name = 'mult_5';
	this.multiplierList = [this.multiplier0, this.multiplier1, this.multiplier2, this.multiplier3, 
							this.multiplier4, this.multiplier5];


	this.addChild(this.initialPlayMultiplier);
	this.addChild(this.multiplier0);
	this.addChild(this.multiplier1);
	this.addChild(this.multiplier2);
	this.addChild(this.multiplier3);
	this.addChild(this.multiplier4);
	this.addChild(this.multiplier5);
	
	this.currentOrder = {status:"bonus",endGame:false, pick:99};
	
	//this.gameState = 'waiting_for_choice';
	this.gameState = 'opening';

	
	this.currentPlay = 0;
	//this.currentPlay = 5;



	//sfx data
	this.bgm = this.game.add.audio('bgm1');
	this.bgm.addMarker('0',0,6.9);
	this.bgm.addMarker('1',7, 7);
	this.bgm.addMarker('2',14,7);
	this.bgm.addMarker('3',21,7);
	this.bgm.addMarker('4',28,7);
	this.bgm.addMarker('5',35,7);
	this.bgm.addMarker('6',42,10);

	this.resetChoiceButtons();
	
	this.bgm.onStop.add(this.bgmEnd,this);
	this.bgm.volume = 0.1;

	this.correct = this.game.add.audio('correctSfx');
	this.finale = this.game.add.audio('wrongSfx');

	this.contPlayFlag = false;
	
	//this.correct.onStop.add(function(){this.continuePlay();},this);
	this.finale.onStop.add(function(){this.endPlay();},this);



	this.danceg = this.game.add.sprite(640,300, 'off_dancer');
	this.danceg.anchor.setTo(0.5,0.5);
	this.addChild(this.danceg);
	//this.danceg.scale.x = 1.1;
	//this.danceg.scale.y = 2.7;
	//this.danceg.smoother = false;
	//this.danceg.tint = "0x000000";
	this.anim2 = this.danceg.animations.add('dance',["dancer_00", "dancer_01", "dancer_02", "dancer_03", "dancer_04", "dancer_05", "dancer_06", "dancer_07", "dancer_08", "dancer_09", "dancer_10", "dancer_11", "dancer_12", "dancer_13", "dancer_14", "dancer_15", "dancer_16", "dancer_17", "dancer_18", "dancer_19", "dancer_20",
	"dancer_20", "dancer_19", "dancer_18", "dancer_17", "dancer_16", "dancer_15", "dancer_14", "dancer_13", "dancer_12", "dancer_11", "dancer_10", "dancer_09", "dancer_08", "dancer_07", "dancer_06", "dancer_05", "dancer_04", "dancer_03", "dancer_02", "dancer_01", "dancer_00"],10,true);
	//this.anim2 = this.danceg.animations.add('dance', Phaser.Animation.generateFrameNames('dancer_',0,20,'',2),10,true);
	//this.anim2 = this.danceg.animations.add('danceReverse', Phaser.Animation.generateFrameNames('dancer_',0,20,'',2).reverse(),10,true);
	
	////console.log(Phaser.Animation.generateFrameNames('dancer_',0,20,'',2));
	////console.log(Phaser.Animation.generateFrameNames('dancer_',0,20,'',2).reverse());
	////console.log(this.anim2);

	//this.anim2.onLoop.add(GameSpriteNoServ2Variables.me.reverseIt,this);


	this.titleText = this.game.add.text(42,42, "You won multiplier X", {font: "42px Arial", fill: "#f26c4f", align: "center"});
	this.titleText.x = 640;
	this.titleText.y = 360;
	this.titleText.visible = false;
	this.addChild(this.titleText);

	this.buttonAvailability = [true,true,true,true,true,true,true,true];


	this.noteEffect = new NoteSwooper(_game,0,0);
	this.addChild(this.noteEffect);


	/*
	this.bgm.play('0');
	this.anim2.play(15,true);
//  */


	
	this.allBlocker = this.addChild(_game.add.sprite(0,0,createRectangleBitmapData(1280,560,"#000000")));
	this.allBlocker.alpha = 0.6;
	this.addChild(this.allBlocker);
	

	this.titleGroup = _game.add.group();
	this.addChild(this.titleGroup);
	this.titleGroup.x = 640;
	this.titleGroup.y = 280;
	this.titleBG = _game.add.sprite(0,0,createRectangleBitmapData(600,400, "#aa0000"));
	this.titleBG.anchor.setTo(0.5,0.5);
	this.titleGroup.add(this.titleBG);

	this.titleBlurb = this.game.add.text(0,0, "click to start", {font: "42px Arial", fill: "#f26c4f", align: "center"});
	this.titleBlurb.x = -120;
	this.titleBlurb.y = 50;
	this.addChild(this.titleBlurb);
	this.titleGroup.add(this.titleBlurb);

	//this.titleButton = new ChoiceSprite(_game, 640,280);
	this.titleButton = new ChoiceSprite(_game, 0,0);
	this.addChild(this.titleButton);
	this.titleButton.inputEnabled = true;
	this.titleButton.name = "openingButton";
	this.titleGroup.add(this.titleButton);

	//this.titleGroup.visible = false;


	this.noteEffect = new NoteSwooper(_game,0,0);
	this.addChild(this.noteEffect);

	this.terminateGame = false;

	this.recievedOrderStringLength = 99;

	this.alpha = 0;


	this.openingAnimationFinished = false;

	//this.exitSignal.dispatch();
	//this._parent.bonusOver();
};

GameSpriteNoServ2.prototype = Object.create(Phaser.Sprite.prototype);
GameSpriteNoServ2.prototype.constructor = GameSpriteNoServ2;
GameSpriteNoServ2.prototype.update = function()
{
	this.gameLoop();
};

GameSpriteNoServ2.prototype.loadDataForStartup = function(dataString)
{
	//pass the data here and lets change the startup animation maybe move it

	//ok compute it all from the last load string
	//console.log("recieved :"+dataString);

	// k lets do the computation here
	var arraySplitter = dataString.split('|');
	//console.log('divided received: '+arraySplitter + " of length "+arraySplitter.length);
	this.recievedOrderStringLength = arraySplitter.length;

	this.currentPlay = arraySplitter.length-1;

	//now get the first element of the last split
	var finalSplit = arraySplitter[arraySplitter.length-1].split(';');
	//console.log('divided final element '+finalSplit);

	//then lets check if its a winner
	var winCheck = finalSplit[0];
	


};

GameSpriteNoServ2.prototype.reverseIt = function()
{
	
	//this.anim2.play('danceReverse');
}

GameSpriteNoServ2.prototype.startMainGame = function()
{
	this.bgm.play('0');
	this.anim2.play(15,true);
	this.warpingWall.playAnimation();
};

GameSpriteNoServ2.prototype.bgmEnd = function()
{

	if(this.terminateGame==false)
	{	
		//console.log("bgm end check: "+this.currentPlay);
		//lets add the check here and then call the special animation for the ending selection
		if(this.currentPlay>=5)
		{
			//do these things instead

			this.choiceGroup.x = 640;
			this.choiceGroup.y = 280;
			this.choiceGroup.scale.setTo(0.8,0.8);
			this.choiceGroup.rotation = 0;

			this.finaleAction = new TimelineMax();
			this.finaleAction.from(this.choiceGroup, 0.5, {y: -100, rotation:500, ease: Circ.easeOut},0);
			this.finaleAction.add(new TweenMax.allTo(this.choiceList, 0.2, {alpha: 1}),0);
			this.finaleAction.add(new TweenMax.allTo(this.choiceList, 0.5, {x:0, y:0}),1);
			this.finaleAction.to(this.choiceGroup.scale, 0.5, {x:4,y:4},1.5);
			this.finaleAction.to(this.choiceGroup, 0.5, {alpha:0},1.5);
			this.finaleAction.add(new TweenMax.delayedCall(0, this.endNoteAnimation),1.75);
			this.finaleAction.play();

			return;
		}


		//console.log('song end');
		this.buttonIn();
		this.anim2.stop();
		this.warpingWall.stopAnimation();

	}else
		{
			//console.log('do the score thing');
			var sayString = '';
			switch(this.currentPlay)
			{
				case 0:
				sayString = "Win multiplier x5";
				break;

				case 1:
				sayString = "Win multiplier x10";
				break;

				case 2:
				sayString = "Win multiplier x15";
				break;

				case 3:
				sayString = "Win multiplier x20";
				break;

				case 4:
				sayString = "Win multiplier x25";
				break;

				case 5:
				sayString = "Win multiplier x50";
				break;
			}

			this.titleText.text = sayString;
			this.titleText.visible = true;

			TweenMax.delayedCall(5, this.animateOut);
		}
};

GameSpriteNoServ2.prototype.endNoteAnimation = function()
{
	//var holder = GameSpriteNoServ2Variables.me.choiceList[GameSpriteNoServ2Variables.me.currentPlay].toGlobal(GameSpriteNoServ2Variables.me.position);
	var holder = {x: GameSpriteNoServ2Variables.me.choiceGroup.x, y: GameSpriteNoServ2Variables.me.choiceGroup.y};

	GameSpriteNoServ2Variables.me.noteEffect.setPointA(holder.x, holder.y);
	GameSpriteNoServ2Variables.me.noteEffect.setPointB(GameSpriteNoServ2Variables.me.multiplierList[GameSpriteNoServ2Variables.me.currentPlay].x, GameSpriteNoServ2Variables.me.multiplierList[GameSpriteNoServ2Variables.me.currentPlay].y);
	
	//lets generate a new button here for animation, make it tween and then remove 1 button from the list
	//ok not a button lets just tween the custom note sprite here so we can call its effects and stuff
	GameSpriteNoServ2Variables.me.noteEffect.startMovement();
	var holder = GameSpriteNoServ2Variables.me.noteEffect.getPointB();

	GameSpriteNoServ2Variables.me.noteEffect.scale.x = 1.5;
	GameSpriteNoServ2Variables.me.noteEffect.scale.y = 1.5;
	
	TweenMax.to(GameSpriteNoServ2Variables.me.noteEffect, 0,{alpha:1});
	TweenMax.to(GameSpriteNoServ2Variables.me.noteEffect, 2,{delay:0.75, x:holder.x, y: holder.y, ease: Back.easeOut, onComplete: GameSpriteNoServ2Variables.me.noteEffectEnd});
};

GameSpriteNoServ2.prototype.gameLoop = function()
{
	
	if(this.isRunning==false) return;
	////console.log('s');
	
};

GameSpriteNoServ2.prototype.animateIn = function()
{
	TweenMax.to(this, 0.25, {alpha:1});
	this.isRunning = true;
	
	this.game.input.onTap.add(this.onTap, this);
};

GameSpriteNoServ2.prototype.animateOut = function()
{
	GameSpriteNoServ2Variables.me.game.input.onTap.remove(GameSpriteNoServ2Variables.me.onTap, GameSpriteNoServ2Variables.me);
	GameSpriteNoServ2Variables.me.exitGame();

	//add the function call to the parent here
};

GameSpriteNoServ2.prototype.buttonIn = function()
{
	//console.log("Current order pick: "+this.currentOrder.pick);
	//tween in the buttons
	this.choice0.inputEnabled = this.buttonAvailability[0];
	this.choice1.inputEnabled = this.buttonAvailability[1];
	this.choice2.inputEnabled = this.buttonAvailability[2];
	this.choice3.inputEnabled = this.buttonAvailability[3];
	this.choice4.inputEnabled = this.buttonAvailability[4];
	this.choice5.inputEnabled = this.buttonAvailability[5];
	//this.choice6.inputEnabled = true;


	this.choice0.resetFace();
	this.choice1.resetFace();
	this.choice2.resetFace();
	this.choice3.resetFace();
	this.choice4.resetFace();
	this.choice5.resetFace();

	this.buttonArrange(this.recievedOrderStringLength);
	
	//this is where we fix the animation

	this.choiceGroup.x = 640; //leave these presettings here for the moment
	this.choiceGroup.y = 280;
	this.choiceGroup.rotation = 0;
	this.choiceList.alpha = 1;
	

	//GameSpriteNoServ2Variables.me.choice0
	var time = 1;
	var wobbleSpace = 200;
	var delayValue = time/5;
	var distanceFromXpos = 900;
	TweenMax.from(GameSpriteNoServ2Variables.me.choice0, time, {x:-distanceFromXpos, yoyo:true, ease:Power0.easeNone, 					  onUpdate:function(){GameSpriteNoServ2Variables.me.choice0.y = wobbleSpace*(Math.sin(this.time()*Math.PI));}}).timeScale(2);
	TweenMax.from(GameSpriteNoServ2Variables.me.choice1, time, {delay:delayValue, x:-distanceFromXpos, yoyo:true, ease:Power0.easeNone,   onUpdate:function(){GameSpriteNoServ2Variables.me.choice1.y = wobbleSpace*(Math.sin(this.time()*Math.PI));}}).timeScale(2);
	TweenMax.from(GameSpriteNoServ2Variables.me.choice2, time, {delay:delayValue*2, x:-distanceFromXpos, yoyo:true, ease:Power0.easeNone, onUpdate:function(){GameSpriteNoServ2Variables.me.choice2.y = wobbleSpace*(Math.sin(this.time()*Math.PI));}}).timeScale(2);
	TweenMax.from(GameSpriteNoServ2Variables.me.choice3, time, {delay:delayValue*3, x:-distanceFromXpos, yoyo:true, ease:Power0.easeNone, onUpdate:function(){GameSpriteNoServ2Variables.me.choice3.y = wobbleSpace*(Math.sin(this.time()*Math.PI));}}).timeScale(2);
	TweenMax.from(GameSpriteNoServ2Variables.me.choice4, time, {delay:delayValue*4, x:-distanceFromXpos, yoyo:true, ease:Power0.easeNone, onUpdate:function(){GameSpriteNoServ2Variables.me.choice4.y = wobbleSpace*(Math.sin(this.time()*Math.PI));}}).timeScale(2);
	TweenMax.from(GameSpriteNoServ2Variables.me.choice5, time, {delay:delayValue*5, x:-distanceFromXpos, yoyo:true, ease:Power0.easeNone, onUpdate:function(){GameSpriteNoServ2Variables.me.choice5.y = wobbleSpace*(Math.sin(this.time()*Math.PI));}}).timeScale(2);
	
	//TweenMax.from(this.choiceGroup, 0.5, {y: -100, rotation:500, ease: Circ.easeOut});
	TweenMax.allTo(this.choiceList, 0.2, {alpha: 1});
	
};

GameSpriteNoServ2.prototype.buttonArrange = function(live_button_count)
{
	//console.log("live button count: "+live_button_count);
	switch(live_button_count)
	{

		case 99:
			//console.log("choice setting 99");
			this.choice0.x = 375;
			this.choice0.y = 0;

			this.choice1.x = 225;
			this.choice1.y = 0;

			this.choice2.x = 75;
			this.choice2.y = 0;

			this.choice3.x = -75;
			this.choice3.y = 0;

			this.choice4.x = -225;
			this.choice4.y = 0;

			this.choice5.x = -375;
			this.choice5.y = 0;

			this.choice0.inputEnabled = true;
			this.choice0.visible = true;
			this.choice1.inputEnabled = true;
			this.choice1.visible = true;
			this.choice2.inputEnabled = true;
			this.choice2.visible = true;
			this.choice3.inputEnabled = true;
			this.choice3.visible = true;
			this.choice4.inputEnabled = true;
			this.choice4.visible = true;
			this.choice5.inputEnabled = true;
			this.choice5.visible = true;

		
		break;


		case 4:
		//console.log("choice setting 4");
			this.choice0.x = 75;
			this.choice0.y = 0;

			this.choice1.x = -75;
			this.choice1.y = 0;

			this.choice0.inputEnabled = true;
			this.choice0.visible = true;
			this.choice1.inputEnabled = true;
			this.choice1.visible = true;
			this.choice2.inputEnabled = false;
			this.choice2.visible = false;
			this.choice3.inputEnabled = false;
			this.choice3.visible = false;
			this.choice4.inputEnabled = false;
			this.choice4.visible = false;
			this.choice5.inputEnabled = false;
			this.choice5.visible = false;
		break;

		case 3:
			//console.log("choice setting 3");
			this.choice0.x = 150;
			this.choice0.y = 0;

			this.choice1.x = 0;
			this.choice1.y = 0;

			this.choice2.x = -150;
			this.choice2.y = 0;

			this.choice0.inputEnabled = true;
			this.choice0.visible = true;
			this.choice1.inputEnabled = true;
			this.choice1.visible = true;
			this.choice2.inputEnabled = true;
			this.choice2.visible = true;
			this.choice3.inputEnabled = false;
			this.choice3.visible = false;
			this.choice4.inputEnabled = false;
			this.choice4.visible = false;
			this.choice5.inputEnabled = false;
			this.choice5.visible = false;



		break;

		case 2:
		//console.log("choice setting 2");
			this.choice0.x = 225;
			this.choice0.y = 0;

			this.choice1.x = 75;
			this.choice1.y = 0;

			this.choice2.x = -75;
			this.choice2.y = 0;

			this.choice3.x = -225;
			this.choice3.y = 0;

			this.choice0.inputEnabled = true;
			this.choice0.visible = true;
			this.choice1.inputEnabled = true;
			this.choice1.visible = true;
			this.choice2.inputEnabled = true;
			this.choice2.visible = true;
			this.choice3.inputEnabled = true;
			this.choice3.visible = true;
			this.choice4.inputEnabled = false;
			this.choice4.visible = false;
			this.choice5.inputEnabled = false;
			this.choice5.visible = false;
			
		break;

		case 1:
		//console.log("choice setting 1");
			this.choice0.x = 300;
			this.choice0.y = 0;

			this.choice1.x = 150;
			this.choice1.y = 0;

			this.choice2.x = 0;
			this.choice2.y = 0;

			this.choice3.x = -150;
			this.choice3.y = 0;

			this.choice4.x = -300;
			this.choice4.y = 0;

			this.choice0.inputEnabled = true;
			this.choice0.visible = true;
			this.choice1.inputEnabled = true;
			this.choice1.visible = true;
			this.choice2.inputEnabled = true;
			this.choice2.visible = true;
			this.choice3.inputEnabled = true;
			this.choice3.visible = true;
			this.choice4.inputEnabled = true;
			this.choice4.visible = true;
			this.choice5.inputEnabled = false;
			this.choice5.visible = false;



		break;

		case 0:   //this should never be called
			//console.log("choice setting 0");
			this.choice0.x = 375;
			this.choice0.y = 0;

			this.choice1.x = 225;
			this.choice1.y = 0;

			this.choice2.x = 75;
			this.choice2.y = 0;

			this.choice3.x = -75;
			this.choice3.y = 0;

			this.choice4.x = -225;
			this.choice4.y = 0;

			this.choice5.x = -375;
			this.choice5.y = 0;

			this.choice0.inputEnabled = true;
			this.choice0.visible = true;
			this.choice1.inputEnabled = true;
			this.choice1.visible = true;
			this.choice2.inputEnabled = true;
			this.choice2.visible = true;
			this.choice3.inputEnabled = true;
			this.choice3.visible = true;
			this.choice4.inputEnabled = true;
			this.choice4.visible = true;
			this.choice5.inputEnabled = true;
			this.choice5.visible = true;

		break;


		default:
			//console.log("default choice activated");
			this.choice0.x = 0;
			this.choice0.y = 0;

			this.choice1.x = 0;
			this.choice1.y = 0;

			this.choice2.x = 0;
			this.choice2.y = 0;

			this.choice3.x = 0;
			this.choice3.y = 0;

			this.choice4.x = 0;
			this.choice4.y = 0;

			this.choice5.x = 0;
			this.choice5.y = 0;

			this.choice0.inputEnabled = false;
			this.choice0.visible = false;
			this.choice1.inputEnabled = false;
			this.choice1.visible = false;
			this.choice2.inputEnabled = false;
			this.choice2.visible = false;
			this.choice3.inputEnabled = false;
			this.choice3.visible = false;
			this.choice4.inputEnabled = false;
			this.choice4.visible = false;
			this.choice5.inputEnabled = false;
			this.choice5.visible = false;


		break;
	}
};

GameSpriteNoServ2.prototype.buttonVisibleSet = function(live_button_count)
{

};

GameSpriteNoServ2.prototype.buttonInCounted = function(count)
{
	this.choice0.visible = count>=0?true:false;
	this.choice1.visible = count>=1?true:false;
	this.choice2.visible = count>=2?true:false;
	this.choice3.visible = count>=3?true:false;
	this.choice4.visible = count>=4?true:false;
	this.choice5.visible = count>=5?true:false;
	//this.choice6.visible = count>=6?true:false;


};

GameSpriteNoServ2.prototype.buttonOut = function()
{
	//tween out then reset buttons

	this.choiceList.alpha = 1;
	TweenMax.to(this.choiceGroup, 0.5, {delay:0.2, y: -100, rotation:500, ease: Circ.easeOut});
	TweenMax.allTo(this.choiceList, 0.2, {alpha: 0});

	this.choice0.inputEnabled = false;
	this.choice1.inputEnabled = false;
	this.choice2.inputEnabled = false;
	this.choice3.inputEnabled = false;
	this.choice4.inputEnabled = false;
	this.choice5.inputEnabled = false;

};

GameSpriteNoServ2.prototype.buttonsHideAfterSelected = function(selectedButtonName)
{
	var ctr = 0;
	for(ctr = 0; ctr<this.choiceList.length;ctr++)
	{
		if(this.choiceList[ctr].name!=selectedButtonName)
		{
			this.choiceList[ctr].inputEnabled = false;
			this.choiceList[ctr].visible = false;
			
		}
	}
};

GameSpriteNoServ2.prototype.resetChoiceButtons = function()
{
	//lets use this to reset the buttons to invisible and off screen for now
	

	this.choice0.alpha = 0;
	this.choice1.alpha = 0;
	this.choice2.alpha = 0;
	this.choice3.alpha = 0;
	this.choice4.alpha = 0;
	this.choice5.alpha = 0;
	//this.choice6.alpha = 0;
	//this.choice7.alpha = 0;
	//this.choice8.alpha = 0;

	this.choice0.inputEnabled = false;
	this.choice1.inputEnabled = false;
	this.choice2.inputEnabled = false;
	this.choice3.inputEnabled = false;
	this.choice4.inputEnabled = false;
	this.choice5.inputEnabled = false;
	//this.choice6.inputEnabled = false;
	//this.choice7.inputEnabled = false;
	//this.choice8.inputEnabled = false;


};

GameSpriteNoServ2.prototype.resetMultiplierDisplays = function()
{
	var ctr = 0;
	for(ctr = 0; ctr < this.multiplierList.length; ctr++)
	{
		this.multiplierList[ctr].switchFace(0);
	}
};

GameSpriteNoServ2.prototype.exitGame = function()
{

	//make a clean exit
	//do the final show thing and then alpha out quickly
	//clean up all listeners as well


	//preparing the data for the next start up
	this.isRunning = false;
	this.choiceGroup.alpha = 0;
	this.resetChoiceButtons();
	this.resetMultiplierDisplays();
	this.gameState = 'opening';
	this.currentPlay = 0;
	this.contPlayFlag = false;
	this.titleGroup.alpha = 0;
	this.titleButton.resetFace();
	this.terminateGame = false;
	this.recievedOrderStringLength = 99;
	this.alpha = 0; //maybe tween this?

	//this.exitSignal.dispatch();
	this._parent.bonusOver();

};

GameSpriteNoServ2.prototype.onTap = function(pointer, doubleTap)
{
	////console.log(this.parent);
	////console.log('im tapped');
	if(pointer.targetObject==null) return;
	//console.log(pointer.targetObject.sprite.name);
	//console.log(this.gameState);
	////console.log(pointer.targetObject.sprite.toGlobal(pointer.targetObject.sprite.position));
	////console.log(pointer.targetObject.sprite.toGlobal(this.position));
	
	
	////console.log("object x: "+pointer.targetObject.sprite.x);
	////console.log("object y: "+pointer.targetObject.sprite.y);
	////console.log("pointer x: "+pointer.x);
	////console.log("pointer y: "+pointer.y);
	
	////console.log(game.input.activePointer.targetObject);


	if(this.gameState == 'opening'&&pointer.targetObject.sprite.name == 'openingButton')
	{
		//console.log('opening check');
		if(this.openingAnimationFinished == false)
		{
			this.titleButton.switchFace(1);

			//then we time a noteswooper call that starts the whole thing
			//this.noteEffect.setDisplay(0);
			var holder = pointer.targetObject.sprite.toGlobal(this.position);   //maybe move this to its function later

			/*
			this.noteEffect.setPointA(holder.x, holder.y);
			this.noteEffect.setPointB(this.initialPlayMultiplier.x, this.initialPlayMultiplier.y);

			this.noteEffect.startMovement();
			holder = this.noteEffect.getPointB();

			TweenMax.to(this.titleGroup, 0.25, {delay:0.75, alpha:0});
			TweenMax.to(this.noteEffect, 0,{delay:0.75, alpha:1});
			TweenMax.to(this.noteEffect, 2,{delay:0.75, x:holder.x, y: holder.y, ease: Back.easeOut, onComplete: this.noteEffectEnd});
			this.openingAnimationFinished = true;
			*/

			this.openingAnimationSequence(holder);

		}
	}

	if(this.gameState == 'waiting_for_choice')
	{

		//add the call to server here 
		// <----- insert HERE ------>

		this.choice0.inputEnabled = false;
		this.choice1.inputEnabled = false;
		this.choice2.inputEnabled = false;
		this.choice3.inputEnabled = false;
		this.choice4.inputEnabled = false;
		this.choice5.inputEnabled = false;

		//var holder = pointer.targetObject.sprite.toGlobal(this.position);
		//this.noteEffect.setPointA(holder.x, holder.y);
		//console.log('selecting');
		var selection = pointer.targetObject.sprite.name;
		
		var split = selection.split('_');
		//console.log(split);
		if(split[0]!='choice') return;

		//this.choiceAnimate(parseInt(split[1]));
		// */


		this.currentOrder.pick = parseInt(split[1]);

		// put in the selection buffer animation here
		// just alpha out every button that is not the selected one
		var ctr = 0;
		for(ctr = 0; ctr < this.choiceList.length;ctr++)
		{
			if(this.choiceList[ctr].name!=selection)
			{
				TweenMax.to(this.choiceList[ctr], 0.25, {alpha:0});
			}
		}



		this.sendChoiceData();
	}
};

GameSpriteNoServ2.prototype.openingAnimationSequence = function(holder)
{
	this.noteEffect.setDisplay(0);
	this.noteEffect.setPointA(holder.x, holder.y);

	if(this.recievedOrderStringLength == 99)  //this is the default animation
	{		
		this.noteEffect.setPointB(this.initialPlayMultiplier.x, this.initialPlayMultiplier.y);

		this.noteEffect.startMovement();
		holder = this.noteEffect.getPointB();

		TweenMax.to(this.titleGroup, 0.25, {delay:0.75, alpha:0});
		TweenMax.to(this.noteEffect, 0,{delay:0.75, alpha:1});
		TweenMax.to(this.noteEffect, 2,{delay:0.75, x:holder.x, y: holder.y, ease: Back.easeOut, onComplete: this.noteEffectEnd});
		this.openingAnimationFinished = true;
	}else
		{
			//if the recievingorderstringlength has a length then the game is a restore so we do this:
			//we make the activated notes before the last note light up
			//then we make the note fly to the last activated note then start the game from there
			
			//activated notes first 
			this.highlightedMultiplierRestore(this.recievedOrderStringLength);

			//now to make the note fly properly
			var targetedMultiplier = this.multiplierList[this.recievedOrderStringLength-1];
			//console.log(this.multiplierList);
			//console.log("current order string length: "+this.recievedOrderStringLength);
			//console.log(this.multiplierList[this.recievedOrderStringLength]);
			//console.log(targetedMultiplier);
			this.noteEffect.setPointB(targetedMultiplier.x, targetedMultiplier.y);

			this.noteEffect.startMovement();
			holder = this.noteEffect.getPointB();


			//the rest of the code repasted
			TweenMax.to(this.titleGroup, 0.25, {delay:0.75, alpha:0});
			TweenMax.to(this.noteEffect, 0,{delay:0.75, alpha:1});
			TweenMax.to(this.noteEffect, 2,{delay:0.75, x:holder.x, y: holder.y, ease: Back.easeOut, onComplete: this.noteEffectEnd});
			this.openingAnimationFinished = true;

		}
};

GameSpriteNoServ2.prototype.highlightedMultiplierRestore = function(restoreNumber)   
{
	if(restoreNumber>=1) this.initialPlayMultiplier.switchFace(1);
	
	if(restoreNumber>=2) this.multiplier0.switchFace(1);

	if(restoreNumber>=3) this.multiplier1.switchFace(1);

	if(restoreNumber>=4) this.multiplier2.switchFace(1);

	if(restoreNumber>=5) this.multiplier3.switchFace(1);

	if(restoreNumber>=6) this.multiplier4.switchFace(1);



};

GameSpriteNoServ2.prototype.choiceAnimate = function(choice)
{
	//console.log('choice is: '+choice);
	this.currentOrder.pick = choice;
	this.gameState = 'processing';
	//this.multiplierList[this.currentPlay].switchFace(1);
	this.getWinner();
};

GameSpriteNoServ2.prototype.getWinner = function ()
{
	this.choice0.inputEnabled = false;
	this.choice1.inputEnabled = false;
	this.choice2.inputEnabled = false;
	this.choice3.inputEnabled = false;
	this.choice4.inputEnabled = false;
	this.choice5.inputEnabled = false;
	

	if(this.currentPlay==this.rolledMultiplier)
	{
		//finalize start
		
		this.doChoiceAnimationFinal();
		

	}else
		{
			//toss the data to the choice animation
			this.doChoiceAnimation(false);
			
		}


};

GameSpriteNoServ2.prototype.removeValueThenRandomize = function(value, list)
{
	list.splice(value, 1);
	var getarray = this.randomizeArray(list);
	return getarray;
};
	
GameSpriteNoServ2.prototype.randomizeArray=function(inArray)
{
	var arr = inArray;
	var arrLength = arr.length;
	var ctr = 0;
	var holder0 = null;
	for(ctr = 0; ctr < arrLength-1; ctr++)
	{
		
		if(Math.random()>0.5)
		{
			//swp it
			holder0 = arr[ctr];
			arr[ctr] = arr[ctr+1];
			arr[ctr+1] = holder0;
		}

		var wildCard = Math.floor(Math.random()*(arrLength-1));
		holder0 = arr[ctr];
		arr[ctr] = arr[wildCard];
		arr[wildCard] = holder0;
	}	

	return arr;
};

GameSpriteNoServ2.prototype.noteEffectEnd = function()
{
	if(GameSpriteNoServ2Variables.me.gameState == 'opening')
	{
		GameSpriteNoServ2Variables.me.noteEffect.goalAchievedExit();
		if(GameSpriteNoServ2Variables.me.recievedOrderStringLength>0&&GameSpriteNoServ2Variables.me.recievedOrderStringLength!=99)
		{
			GameSpriteNoServ2Variables.me.multiplierList[GameSpriteNoServ2Variables.me.recievedOrderStringLength-1].switchFace(1);
		}else
			{
				GameSpriteNoServ2Variables.me.initialPlayMultiplier.switchFace(1);	
			}
		GameSpriteNoServ2Variables.me.gameState = 'waiting_for_choice'

		TweenMax.to(GameSpriteNoServ2Variables.me.allBlocker, 0.2, {alpha:0});
		GameSpriteNoServ2Variables.me.startMainGame();	
		return;
	}

	if(GameSpriteNoServ2Variables.me.terminateGame==false){
		//console.log("doop dee doo");
		//console.log(GameSpriteNoServ2Variables.me);
		GameSpriteNoServ2Variables.me.noteEffect.goalAchievedExit();
		GameSpriteNoServ2Variables.me.multiplierList[GameSpriteNoServ2Variables.me.recievedOrderStringLength-1].switchFace(1);
		GameSpriteNoServ2Variables.me.continuePlay();
		return;
	}
	
	if(GameSpriteNoServ2Variables.me.terminateGame==true)
	{
		//console.log('terminating');
		GameSpriteNoServ2Variables.me.noteEffect.goalAchievedExit();
		GameSpriteNoServ2Variables.me.multiplierList[GameSpriteNoServ2Variables.me.currentPlay].switchFace(2);
		GameSpriteNoServ2Variables.me.endPlay();
		GameSpriteNoServ2Variables.me.buttonOut();
		return;
	}

	//console.log('this should never display');
};

GameSpriteNoServ2.prototype.doChoiceAnimation = function(end)
{
	//console.log('recieved string length: '+this.recievedOrderStringLength);
	var picked = this.currentOrder.pick;
	
	var correctList = [picked];

	this.buttonAvailability[picked] = false;
	
	this.choiceList[picked].switchFace(1);
	this.noteEffect.setDisplay(0);
	var holder = this.choiceList[picked].toGlobal(this.position);
	this.noteEffect.setPointA(holder.x, holder.y);
	this.noteEffect.setPointB(this.multiplierList[this.recievedOrderStringLength-1].x, this.multiplierList[this.recievedOrderStringLength-1].y);
	
	//lets generate a new button here for animation, make it tween and then remove 1 button from the list
	//ok not a button lets just tween the custom note sprite here so we can call its effects and stuff
	this.noteEffect.startMovement();
	var holder = this.noteEffect.getPointB();

	TweenMax.to(this.noteEffect, 0,{delay:0.75, alpha:1});
	TweenMax.to(this.noteEffect, 1,{delay:0.75, x:holder.x, y: holder.y, ease: Back.easeOut, onComplete: this.noteEffectEnd});

	this.correct.play();
	//add sound effects then animation for correct pick

	//this.correct.onStop.add(function(){this.continuePlay();});

/*
	this.currentPlay++;
	var stringed = this.currentPlay.toString();
	//console.log(stringed);
	this.bgm.play(stringed);
*/


};

GameSpriteNoServ2.prototype.doChoiceAnimationFinal = function(winningMultiplier)
{
	//console.log("recieved for final: "+winningMultiplier);
	this.terminateGame = true;
	var picked = this.currentOrder.pick;
	
	this.choiceList[picked].switchFace(2);

	//at this point seperate the finale into either failure state or final mode state so we can tack on some animation
	if(picked>=5)
	{
		//console.log('do final mode animation');
	}else
		{
			this.noteEffect.setDisplay(1);
			//console.log('do early finish mode');
			var holder = this.choiceList[picked].toGlobal(this.position);
			this.noteEffect.setPointA(holder.x, holder.y);
			this.noteEffect.setPointB(this.multiplierList[this.currentPlay].x, this.multiplierList[this.currentPlay].y);
			

			//lets generate a new button here for animation, make it tween and then remove 1 button from the list
			//ok not a button lets just tween the custom note sprite here so we can call its effects and stuff
			this.noteEffect.startMovement();
			var holder = this.noteEffect.getPointB();

			TweenMax.to(this.noteEffect, 0,{delay:0.75, alpha:1});
			TweenMax.to(this.noteEffect, 1,{delay:0.75, x:holder.x, y: holder.y, ease: Back.easeOut, onComplete: this.noteEffectEnd});

			this.finale.play();
		}

};


GameSpriteNoServ2.prototype.continuePlay = function()
{

	if(this.currentPlay>=5)
	{
		//console.log('do the end thing');
		this.buttonOut();
		var stringed = this.currentPlay.toString();
		//console.log(stringed);
		this.endPlay();
		this.anim2.play();
		this.gameState = 'waiting_for_choice';
		this.warpingWall.playAnimation();	
		this.terminateGame = true;
		return;
	};

	this.buttonOut();
	this.currentPlay++;
	var stringed = this.currentPlay.toString();
	//console.log(stringed);
	this.bgm.play(stringed);
	this.anim2.play();
	this.gameState = 'waiting_for_choice';
	this.warpingWall.playAnimation();
};

GameSpriteNoServ2.prototype.endPlay = function()
{
	this.bgm.play('6');
	this.anim2.play();
	this.warpingWall.playAnimation();
};

GameSpriteNoServ2.prototype.sendChoiceData = function()
{
	//this._parent.getDataRequest();

	this.recieveChoiceData(this.getData());
};

GameSpriteNoServ2.prototype.recieveChoiceData = function(dataString)
{
	//console.log("recieved :"+dataString);

	// k lets do the computation here
	var arraySplitter = dataString.split('|');
	//console.log('divided received: '+arraySplitter + " of length "+arraySplitter.length);
	this.recievedOrderStringLength = arraySplitter.length;

	//now get the first element of the last split
	var finalSplit = arraySplitter[arraySplitter.length-1].split(';');
	//console.log('divided final element '+finalSplit);

	//then lets check if its a winner
	var winCheck = finalSplit[0];
	if(winCheck[0]!="0")
	{
		//console.log('winning roll');
		this.doChoiceAnimationFinal(winCheck);
	}else
		{
			//console.log('normal roll');
			this.doChoiceAnimation(false);
		}
};


GameSpriteNoServ2.prototype.generateMockData = function()
{	
	
	//console.log('generating mock data for v3');
	//first we roll for the actual bonus (1-6)
	var rolledNumber = this.game.rnd.integerInRange(0,5);
	var rolledNumber = 5;
	
	this.winningRoll = rolledNumber;
	var outString = "";
	//console.log('rolled '+this.winningRoll);

	//now based on the rolled number we fill the responseString

	//but first lets check if it terminates on the first check
	if(rolledNumber == 0)
	{
		//add the terminating value to the string then return 
		outString = "2:0";
		this.responseString = outString;
		return;
	}

	var ctr = 0;
	for(ctr = 0; ctr <= rolledNumber; ctr++)
	{
		if(ctr == 0 )
		{
			//make sure the first one does not have a divider

			outString = "0;0";
			//console.log("initial: "+outString);
		}else
			if(ctr == rolledNumber) //if were at the terminator then add it
			{
				outString = outString+"|2;0"; //change this later
				//console.log("final: "+outString);
			}else
				{ 	//if were here then we just add a filler
					outString = outString+"|0;0";
					//console.log("filler: "+outString);
				}
	}

	//console.log("generate string: "+outString);
	this.responseString = outString;
	return;

};

GameSpriteNoServ2.prototype.getData = function()
{	
	/*
	this.currentRollReturned++;
	return this.responseString;
	*/

	if(this.currentRollReturned>=this.winningRoll)
	{
		//return the whole string
		return this.responseString;
	}else
		{
			//else piecemeal it from the number of currentRollReturns
			if(this.currentRollReturned == 0)
			{
				var toRetString = this.responseString.slice(0,3);
				this.currentRollReturned++;
				return toRetString;
			}else
				{
					var toRetString = this.responseString.slice(0, 3+(4*this.currentRollReturned))
					this.currentRollReturned++;
					return toRetString;
				}

		}

};


//helper functions
function createRectangleBitmapData(_width, _height, color)
{
	var bmd = GameSpriteNoServ2Variables.me.game.add.bitmapData(_width,_height);
	bmd.context.fillStyle = color;
	bmd.context.fillRect(0,0,_width,_height);

	return bmd;
}








MockServerBuiltIn3 = function()
{
	this.responseString = "";
	this.winningRoll = 0;
	this.currentRollReturned = 0;
};

MockServerBuiltIn3.prototype.generateMockData = function()
{	
	
	//console.log('generating mock data for v3');
	//first we roll for the actual bonus (1-6)
	var rolledNumber = this.game.rnd.integerInRange(0,5);
	var rolledNumber = 5;
	
	this.winningRoll = rolledNumber;
	var outString = "";
	//console.log('rolled '+this.winningRoll);

	//now based on the rolled number we fill the responseString

	//but first lets check if it terminates on the first check
	if(rolledNumber == 0)
	{
		//add the terminating value to the string then return 
		outString = "2:0";
		this.responseString = outString;
		return;
	}

	var ctr = 0;
	for(ctr = 0; ctr <= rolledNumber; ctr++)
	{
		if(ctr == 0 )
		{
			//make sure the first one does not have a divider

			outString = "0;0";
			//console.log("initial: "+outString);
		}else
			if(ctr == rolledNumber) //if were at the terminator then add it
			{
				outString = outString+"|2;0"; //change this later
				//console.log("final: "+outString);
			}else
				{ 	//if were here then we just add a filler
					outString = outString+"|0;0";
					//console.log("filler: "+outString);
				}
	}

	//console.log("generate string: "+outString);
	this.responseString = outString;
	return;

};

MockServerBuiltIn3.prototype.getData = function()
{	
	/*
	this.currentRollReturned++;
	return this.responseString;
	*/

	if(this.currentRollReturned>=this.winningRoll)
	{
		//return the whole string
		return this.responseString;
	}else
		{
			//else piecemeal it from the number of currentRollReturns
			if(this.currentRollReturned == 0)
			{
				var toRetString = this.responseString.slice(0,3);
				this.currentRollReturned++;
				return toRetString;
			}else
				{
					var toRetString = this.responseString.slice(0, 3+(4*this.currentRollReturned))
					this.currentRollReturned++;
					return toRetString;
				}

		}

};

MockServerBuiltIn3.prototype.sendData = function(dataGroup)
{
	

};

MockServerBuiltIn3.prototype.validateRecieved = function(data)
{
	

};


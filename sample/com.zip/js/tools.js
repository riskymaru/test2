
	//* ADD MATH TOOLS*//

	//trace a value,(console.log only)
	var trace = function _trace(){
	        this.arr = []
	         for (i = 0; i < arguments.length; i++) {
	             this.arr.push(arguments[i]);
	         }
	       console.info('✯',this.arr/*,"[Caller]>",arguments.callee.caller*/);//error/debug/log/info/warn/►
	}

	//-------------------------------------------
	var NumCom = function ReplaceNumberWithCommas(yourNumber) {
	   	yourNumber = Math.round(yourNumber*100)/100
	    var n= yourNumber.toString().split(".");
	    n[0] = n[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	    return n.join(".");
	}

	NumCom.prototype.constructor = NumCom

	var NumRound = function round(num){
	    return Math.round(num*100)/100;
	}
	NumRound.prototype.constructor = NumRound


	var deg2rad = function _deg2rad(num){
	    return Math.round(num*0.0174532925);
	}
	deg2rad.prototype.constructor = deg2rad

	//------------------------------------------------------------------------------------------------------------------------------------

	//*OTHER TOOLS*//

    var gamex = {}
	var gba = {}
	var JSctr = 0;
	var JStotal = 1;
	var includeJs = function(jsFilePath) {
			var js;
			js = document.createElement("script");
			js.type = "text/javascript";
			js.src = jsFilePath;
			document.body.appendChild(js);
			JSctr++;
			console.log(jsFilePath);
			if(JSctr==JStotal) js.addEventListener("load",onLoads);//setTimeout(5,callLoad);
	}

	function onLoads(){

	}

    var Pic = function _Pic(x,y,img){
        Phaser.Image.call(this, gamex, x, y,img);
        this.inputEnabled = false
        this.blendModes = 0
        this.input = new Phaser.InputHandler(this)
        this.body = null
        this.anchor.setTo(0.5,0.5);
        this.alive = false
        this.checkWorldBounds = false
        this.outOfBoundsKill = true;
        this.smoothed = false
        this.pivot.setTo(0.5,0.5)
        this.texture.baseTexture.scaleMode = PIXI.scaleModes.NEAREST;

        return this;
    } 
    Pic.prototype = Object.create(Phaser.Image.prototype);
    Pic.prototype.constructor = Pic
    //-------------------------------------------

     var Sprite = function _Sprite(x,y,img,frame){
        Phaser.Sprite.call(this, gamex, x, y,img);
        this.inputEnabled = false
        this.blendModes = 0
        this.input = new Phaser.InputHandler(this)
        this.input.priorityID = 0
        frame == null ? 0 : this.frameName = frame
        this.body = null
        this.anchor.setTo(0.5,0.5);
        this.alive = false
        this.checkWorldBounds = false
        this.outOfBoundsKill = true;
        this.pivot.setTo(0.5,0.5)
        this.smoothed = false
        this.texture.baseTexture.scaleMode = PIXI.scaleModes.NEAREST;

        return this;
    }
    Sprite.prototype = Object.create(Phaser.Sprite.prototype);
    Sprite.prototype.constructor = Sprite


    //-------------------------------------------

    var TextField = function _TextField(str,sz,x,y,algn){
            Phaser.Image.call(this,gamex,x,y,0,"")
            this.input = new Phaser.InputHandler(this)
            this.input.priorityID = 0
            this.pivot.setTo(0.5,0.5)
            this.anchor.setTo(0.5,0.5)
            this.checkWorldBounds = false
            this.inputEnabled = false
            this.blendModes = 0
            this.smoothed = true
            this.body = null
            sz == null? sz = 18 : 0;

            !algn ? algn = "left" : 0

            //algn = 'left'
           /* this.text = new Phaser.BitmapText(gamex,0, 0, style, 'sample_text', sz,'right');//new Phaser.BitmapText(gamex,0,0,style,str,sz)//game.add.bitmapText(0, 0, 'led', 'sample text', 20);//new Phaser.Text(game,this.tx_x,0,str,this.style)//game.add.text(x+(w*0.5),y, "Sample Text", this.style);//
            this.addChild(this.text)
            this.text.setText(str);
            this.text.wordWrap = true;
            //this.text.right= 200
            //this.text.maxWidth   = 50
            this.text.tint = "#666666"
            this.text.setTextBounds(16, 16, 768, 568);
            
            if(border){
                this.txt_bg = game.add.graphics( 0, 0 );
                this.txt_bg.beginFill(0x0, 1);
                this.txt_bg.bounds = new PIXI.Rectangle(0, 0, w, h);
                this.txt_bg.drawRect(0, 0, w, h);
                this.txt_bg.alpha = 0.25
                this.addChild(this.txt_bg)
            }*/

            var style = { font: "bold " + sz +"px venus_risingregular", 
                fill: "#fff", 
                align: algn,            // 'left', 'center' or 'right'.
                boundsAlignH: algn,  //'left', 'center' or 'right'.
                boundsAlignV: "center",    //middle,top,bottom
                stroke:"",             
                wordWrap: true, wordWrapWidth: 600 };

                this.text = new Phaser.Text(gamex,0, 0, str, style);
                algn == 'center' ? this.text.anchor.set(0.5,0.5) :  0
                this.addChild(this.text)

                return this;
    }
    TextField.prototype = Object.create(Phaser.Image.prototype);
    TextField.prototype.constructor = TextField
    //-------------------------------------------

    var Drag =  function _Drag(p_obj,start_d,stop_d,dir,smooth,id1,id2){

        var i = 0
        var j = 0
        var k = 0
        var l = 0
        var ox = 0

        var distance = 100

        p_obj.inputEnabled = true;
        p_obj.input.enableDrag();
        p_obj.input.useHandCursor = true
        p_obj.dir = 0

        !dir ? dir = 0 : 0;

        !smooth ? smooth = false : 0;

        p_obj.events.onDragStart.add(drag_start, gamex)
        p_obj.events.onDragStop.add(drag_end, gamex)

        if(dir==2){
            p_obj.input.allowVerticalDrag = false
            p_obj.input.allowHorizontalDrag = true
        }else
        if(dir=1){
            p_obj.input.allowVerticalDrag = true
            p_obj.input.allowHorizontalDrag = false
        }else
        if(dir=0){
            p_obj.input.allowVerticalDrag = true
            p_obj.input.allowHorizontalDrag = true
        }


        function drag_start(){
            i = gamex.input.mousePointer.x
            ox = p_obj.x
            start_d ? start_d() : 0
        }

        function drag_end(){

            if(smooth){  
                    j = gamex.input.mousePointer.x
                    k = i - j//p_obj.x +(j)
                    k < 0 ? k *= - 1 : 0 ;

                    trace(k,distance,i,j,'k')
                    if(k<distance){
                        p_obj.dir = 5
                        p_obj.x = ox
                    }else{
                        trace('good')
                        if(i>j){
                            p_obj.dir = -1
                        }else
                        if(i<j){
                            p_obj.dir = 1
                        }
                    }
            }
            //call other
            stop_d ? stop_d(p_obj) : 0
        }

        return p_obj;
    }
    Drag.prototype.constructor = Drag;
   


    //-------------------------------------------
    var Tap = function _Tap(p_obj,p_up,p_down,p_over,p_out,p_center){
    		p_obj.inputEnabled = true;
            p_obj.input.priorityID = 0
            p_obj.input.useHandCursor = true
            p_obj.input.pixelPerfectAlpha = 1
            p_obj.input.pixelPerfectOver = true
    		/*if(p_up!=null){p_obj.events.onInputUp.add(p_up, gamex)};
    		if(p_down!=null){p_obj.events.onInputDown.add(p_down, gamex)};
    		if(p_over!=null){p_obj.events.onInputOver.add(p_over, gamex)};
    		if(p_out!=null){p_obj.events.onInputOut.add(p_out, gamex)};*/


            if(p_up!=null){p_obj.events.onInputUp.add(p_up, gamex)};
            if(p_down!=null){p_obj.events.onInputDown.add(p_down, gamex)};
            if(p_over!=null){p_obj.events.onInputOver.add(p_over, gamex)};
            if(p_out!=null){p_obj.events.onInputOut.add(p_out, gamex)};


            return p_obj;
    }
    Tap.prototype.constructor = Tap;
    //-------------------------------------------

    //-------------------------------------------
    var Press = function _Press(game,key,kyUp,kyDown){
            game.input.keyboard.onUpCallback = function(e){
            if(e.keyCode == key){
               kyUp();
            }
        }
    };
    Press.prototype.constructor = Press;
     //-------------------------------------------

     /*
        PIXI.blendModes = {
            NORMAL:0,
            ADD:1,
            MULTIPLY:2,
            SCREEN:3,
            OVERLAY:4,
            DARKEN:5,
            LIGHTEN:6,
            COLOR_DODGE:7,
            COLOR_BURN:8,
            HARD_LIGHT:9,
            SOFT_LIGHT:10,
            DIFFERENCE:11,
            EXCLUSION:12,
            HUE:13,
            SATURATION:14,
            COLOR:15,
            LUMINOSITY:16
        };
     */
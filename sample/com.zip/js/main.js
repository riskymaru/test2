document.addEventListener("DOMContentLoaded", function(event) { 

		//*SETUP*//	

		var isMobile = {
					    Android: function() {
					        return /Android/i.test(navigator.userAgent);
					    },
					    BlackBerry: function() {
					        return /BlackBerry/i.test(navigator.userAgent);
					    },
					    iOS: function() {
					        return /iPhone|iPad|iPod/i.test(navigator.userAgent);
					    },
					    Windows: function() {
					        return /IEMobile/i.test(navigator.userAgent);
					    },
					    any: function() {
					        return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Windows());
					    }
					};

		window.getDevicePixelRatio = function () { //
					    var ratio = 1;
					    // To account for zoom, change to use deviceXDPI instead of systemXDPI
					    if (window.screen.systemXDPI !== undefined && window.screen.logicalXDPI !== undefined && window.screen.systemXDPI > window.screen.logicalXDPI) {
					        // Only allow for values > 1
					        ratio = window.screen.systemXDPI / window.screen.logicalXDPI;
					    }
					    else if (window.devicePixelRatio !== undefined) {
					        ratio = window.devicePixelRatio;
					    }
					    return ratio;
					};//~getDevicePixelRatio

		//------------------------------------------------------------------------------------------------------------------------------------

		//------------------------------------------------------------------------------------------------------------------------------------

	    /**PLATFORM SETTINGS*/
		window.onload = function () {

				document.getElementById('game_canvas').innerHTML = '';

				var game = {}; //phaser game
				var slot = {}; //slot class
				var ratio = Math.ceil(window.getDevicePixelRatio());
				var window_width =  Math.ceil($(window).width() * ratio);
				var window_height =  Math.ceil($(window).height() * ratio);
				var model = 0; //0=desktop || 1=iphone4 || 2=ipad
				var view = 0; //0 landscape || 1= portrait
				var _mw,_mh; 
				var gamer_render = {}
				var mobile = false

				/* TESTING MODE*/
				game.test = false;
				slot.mobile = mobile
				slot.kineticScrolling = {}

				//check view
				if(window.orientation==undefined){	window_width > window_height ? view = 0 : view= 1 }	
				else{	window.orientation == 0 ? view = 1 : view = 0 	};

				//initialize the framework
				slot.mobile = isMobile.any()

				if(mobile){
					_gw = 800//1280//800
					_gh = 350//560//350//450//450
				}else{
					_gw = 1280//1280//800
					_gh = 560
				}

				/*Note: GameRender
				WEBGL = 2 | CANVAS = 1 | AUTO = 0*/
				
				gamer_render = 1

				game = new Phaser.Game(_gw, _gh, gamer_render, 'game_canvas',null,true,true,false);

				//slot init
				slot.slot_spin = [0,0,0,0,0]

				//game setup
				//--------------------------------------------------------------------------
				slot.be = {}
				slot.gamer_render = gamer_render
				slot.gw = _gw
				slot.gh = _gh
				slot.full_screen = false
				slot.turbo = false
				slot.auto_spin_num = 0;
				slot.auto_spin_mode = false
				slot.fast_spin = 0
				slot.bet_num = 0
				slot.line_num = 0
				slot.info_page_id = 0
				slot.sym_name = ['sym1','sym2','sym3','sym4','sym5','sym6','sym7','sym8','sym9','sym10','sym11','sym12','sym13',
								 'sym1','sym2','sym3','sym4','sym5','sym6','sym7','sym8','sym9','sym10','sym11','sym12','sym13',
								 'sym1','sym2','sym3','sym4','sym5','sym6','sym7','sym8','sym9','sym10','sym11','sym12','sym13',
								 'sym1','sym2','sym3','sym4','sym5','sym6','sym7','sym8','sym9','sym10','sym11','sym12','sym13']
				//--------------------------------------------------------------------------
				slot.goFullScreen = function _goFullScreen(){
					 game.scale.fullScreenScaleMode = Phaser.ScaleManager.SHOW_ALL//EXACT_FIT//SHOW_ALL//;
					 //phaser fullscreen
					  if (game.scale.isFullScreen) {
					     	game.scale.stopFullScreen();
					   	 	slot.fullscreen_flag = false
					   	 	slot.adjust_screen_height(false)
					  } else {
					 	 	game.scale.startFullScreen(); 
					 	 	slot.fullscreen_flag = true  
					 	 	slot.adjust_screen_height(true)
					  }
				}//full_screen

				//init external functions
				slot.boot = function(game){};
				slot.boot.prototype = {
				  preload: function(){
				   	//preload the loading indicator first before anything else
				    this.load.image('preloader_bg', 'assets/html5/img/preloader/preloader_bg.jpg');
				   	this.load.image('bar1','assets/html5/img/preloader/preloaderbar1.jpg')
				    this.load.image('bar2','assets/html5/img/preloader/preloaderbar2.jpg')
				  },
				  create: function(game){
				    // set scale options
				    game.renderer.clearBeforeRender = true;
    				game.renderer.roundPixels = true;
				    this.stage.disableVisibilityChange = true;
				    this.game.stage.smoothed = false;
				    this.input.maxPointers = 1;

				    this.scale.maxIterations = 1;
				    this.scale.pageAlignHorizontally = true;
				    this.scale.pageAlignVertically = true;

					this.game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;  
				    
				    this.game.scale.maxHeight = 720
				    this.game.scale.maxWidth = 1280
				    
				    //this.game.scale.setUserScale(1, 1, 2, 2)
				    this.game.scale.refresh()
					this.game.renderer.renderSession.roundPixels = true; 
					Phaser.Canvas.setImageRenderingCrisp(this.game.canvas) 
					Phaser.Canvas.setSmoothingEnabled(gamex.context, false);

			        this.state.start('preloader');// start the Preloader state
				  }
				};

				be1(game,slot);

				st1(game,slot);
				
				//PRELOADER
				slot.preloader = function(game){}


				slot.preloader.prototype = {
					   preload: function(){
					   	trace('loading...')
				        /*        Setup Preloader        */
				        //on-going-project
				        slot.ogp_game = 'dangdut'//dangdut//deadpool
				        this.stage.backgroundColor = '#050505';
				        //this.bg = this.add.sprite(0,0,(slot.view == 0? "background" : "background2"))
				        this.preloaderBar_bg = this.add.sprite(0, 50, 'preloader_bg');
				        this.preloadBar1 = this.add.sprite(420,480, 'bar2');
				        this.preloadBar2 = this.add.sprite(420,480, 'bar1');
				     	this.load.setPreloadSprite(this.preloadBar2);

				     	//fonts
				     	this.load.script('webfont', '//ajax.googleapis.com/ajax/libs/webfont/1.4.7/webfont.js');
						this.load.bitmapFont('led', 'assets/html5/fonts/led.png', 'assets/html5/fonts/led.fnt');
						this.load.bitmapFont('small_led', 'assets/html5/fonts/small_led.png', 'assets/html5/fonts/small_led.fnt');

						//bitmapfont
						this.load.bitmapFont('agency', 'assets/html5/img/'+ slot.ogp_game +'/fnt/agency.png', 'assets/html5/img/'+ slot.ogp_game +'/fnt/agency.fnt');
				        this.load.bitmapFont('copper', 'assets/html5/img/'+ slot.ogp_game +'/fnt/copper.png', 'assets/html5/img/'+ slot.ogp_game +'/fnt/copper.fnt');
				        this.load.bitmapFont('flappy', 'assets/html5/img/'+ slot.ogp_game +'/fnt/flappy.png', 'assets/html5/img/'+ slot.ogp_game +'/fnt/flappy.fnt');
				        this.load.bitmapFont('venus_num', 'assets/html5/img/'+ slot.ogp_game +'/fnt/venus_num.png', 'assets/html5/img/'+ slot.ogp_game +'/fnt/venus_num.fnt');

				        //load image
				        this.load.image('logo','assets/html5/img/'+ slot.ogp_game +'/logo/logo.png')
				        this.load.image('bottom_bar','assets/html5/img/'+ slot.ogp_game +'/bg/header.jpg')

				        //background
				        this.load.image('bg2','assets/html5/img/'+ slot.ogp_game +'/bg/bg.jpg')
				        this.load.image('bg','assets/html5/img/'+ slot.ogp_game +'/bg/bg2.jpg')
				     
				     	//characters
				        this.load.image('char1','assets/html5/img/'+ slot.ogp_game +'/others/char1.png')
				        this.load.image('char2','assets/html5/img/'+ slot.ogp_game +'/others/char2.png')
				        this.load.image('free_spin','assets/html5/img/'+ slot.ogp_game +'/others/char2.png')

				        //buttons
				        this.load.image('btn_auto','assets/html5/img/'+ slot.ogp_game +'/btn/btn_auto.png')
				        this.load.image('spin_btn','assets/html5/img/'+ slot.ogp_game +'/btn/spin2.png')
				        this.load.atlas('btn', 'assets/html5/img/' + slot.ogp_game + '/btn/btn.png', 'assets/html5/img/'+ slot.ogp_game +'/btn/btn.json' )
				        this.load.image('transparent_gradient','assets/html5/img/'+ slot.ogp_game +'/btn/transparent_gradient.png')
						this.load.atlas('free_spin_option', 'assets/html5/img/' + slot.ogp_game + '/btn/free_spin_option.png', 'assets/html5/img/'+ slot.ogp_game +'/btn/free_spin_option.json' )

				        //symbols
				        this.load.image('sym1','assets/html5/img/' + slot.ogp_game + '/symbols/sym0001.png')
				        this.load.image('sym2','assets/html5/img/' + slot.ogp_game + '/symbols/sym0002.png')
				        this.load.image('sym3','assets/html5/img/' + slot.ogp_game + '/symbols/sym0003.png')
				        this.load.image('sym4','assets/html5/img/' + slot.ogp_game + '/symbols/sym0004.png')
				        this.load.image('sym5','assets/html5/img/' + slot.ogp_game + '/symbols/sym0005.png')
				        this.load.image('sym6','assets/html5/img/' + slot.ogp_game + '/symbols/sym0006.png')
				        this.load.image('sym7','assets/html5/img/' + slot.ogp_game + '/symbols/sym0007.png')
				        this.load.image('sym8','assets/html5/img/' + slot.ogp_game + '/symbols/sym0008.png')
				        this.load.image('sym9','assets/html5/img/' + slot.ogp_game + '/symbols/sym0009.png')
				        this.load.image('sym10','assets/html5/img/' + slot.ogp_game + '/symbols/sym0010.png')
				        this.load.image('sym11','assets/html5/img/' + slot.ogp_game + '/symbols/sym0011.png')
				        this.load.image('sym12','assets/html5/img/' + slot.ogp_game + '/symbols/sym0012.png')
				        this.load.image('sym13','assets/html5/img/' + slot.ogp_game + '/symbols/sym0013.png')


				        this.load.pack('bonusAssets','assets/html5/js/other/DQ_bonus_asset_pack.json',null,this);



				        //bonus
				   
				        //INFO
				        this.load.image('payline','assets/html5/img/'+ slot.ogp_game + '/info/payline.jpg')

				        //load audio

				        //this.load.audio('heavy','assets/html5/snd/heavy.mp3');
				        this.load.audio('snd_btn_add',['assets/html5/snd/bet_add.mp3','assets/html5/snd/bet_add.wav','assets/html5/snd/bet_add.ogg']);

				        this.load.audio('reel1a',['assets/html5/snd/bet_add.mp3','assets/html5/snd/bet_add.wav','assets/html5/snd/bet_add.ogg']);
				        slot.be.get_variable(slot);

				        this.load.onLoadComplete.add(loadComplete, this);
				        function loadComplete(){
				           slot.be.request_load(slot);
				           //this.state.start('main_menu');
				        }
				    },
				    create: function(){

				    }
				};

			gamex = game
			game.state.add('boot',slot.boot)
			game.state.add('preloader',slot.preloader)
			game.state.add('main_menu', slot.main_menu);
			game.state.start('boot');


		}//onload

});//~end of code
	


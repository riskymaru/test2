function be1(game,slot){
	//init all val
	slot.be._BASE_URL = "http://192.168.248.92/test_sky_pirate/"

	slot.be.free_spin_num = 0

	//from PHP

	slot.be.response = -1//'{"R":"9;10;8;5;6;4;3;0;7;1;2;6;4;8;10;5;1;9;6;0;11;7;4;3;6;8;4;7;2;5;9;3;0;6;1;4;10;2;5;7;3;8;11;|4;3;6;1;2;8;5;6;11;4;9;0;7;4;5;9;10;0;8;5;7;2;4;9;3;5;6;12;7;10;5;3;7;1;0;6;8;7;10;12;3;8;1;2;11;|2;3;6;1;11;7;8;0;5;12;9;4;6;11;5;10;12;7;4;3;8;10;0;7;3;6;5;4;12;9;8;5;4;|10;5;3;8;11;12;6;1;9;11;4;7;2;10;8;3;1;6;0;4;11;5;12;9;7;2;0;8;3;10;5;4;9;1;12;2;6;|3;10;7;1;2;8;3;11;5;9;0;6;1;2;8;10;7;5;6;4;9;3;11;2;1;10;5;9;3;10;11;0;2;9;1;4;11;|"}'
	slot.be.fromPHP = {}//JSON.parse(slot.be.fromPHP);

	slot.be.r = new Array();

	slot.be.BPL = [ 0.1, 0.2, 0.5, 0.8, 1, 1.5];
	slot.be.WIN = 0;
	slot.be.BET = 5;
	slot.be.N = 30;
	slot.be.S = "42|40|21|2|36"
	slot.be.S = slot.be.S.split('|')
  slot.be.numFR = 0
	slot.be.L = []
  slot.be.LS = {}
  slot.be.game_screen = 0

	slot.be.get_variable = function(slot){
         $.ajax({
            type: "POST",
            url: slot.be._BASE_URL  + 'get_variable',
            data: {
              //data_ : JSON.stringify({"N" : 30, "BPL": 0.5, "token" : _token})
            },
            dataType: 'text',
            success: function(fromPHP) {
              slot.be.fromPHP = JSON.parse(fromPHP.split('=')[1]);
            },
            error : function (xhr, fromPHP, txt) {
              console.log(xhr);
              console.log(fromPHP);
              console.log(txt);
            }
          });
    };

    slot.be.request_load = function(slot){
        $.ajax({
            type: "POST",
            url: slot.be._BASE_URL  + 'load',
            data: {
              data_ : JSON.stringify({"sv":"","player":true})
            },
            dataType: 'text',
            success: function(fromPHP) {
              slot.be.fromPHP = JSON.parse(fromPHP.split('=')[1]);
              slot.be.check_reponse(slot);
              game.state.start('main_menu');
            },
            error : function (xhr, fromPHP, txt) {
              console.log(xhr);
              console.log(fromPHP);
              console.log(txt);
            }
          });
    };


    slot.be.request_spin = function(slot,id){
        $.ajax({
          type: "POST",
          url: slot.be._BASE_URL + 'spin',
          data: {
            data_ : JSON.stringify({"N" : 30, "BPL": 0.5, "token" : slot.be.token})
          },
          dataType: 'text',
          success: function(fromPHP) {
            slot.be.fromPHP = JSON.parse(fromPHP.split('=')[1]);
            slot.be.check_reponse(slot);
          },
          error : function (xhr, fromPHP, txt) {
            console.log(xhr);
            console.log(fromPHP);
            console.log(txt);
          }
        });
    };

    slot.be.request_free_option = function(slot,id){
        $.ajax({
          type: "POST",
          url: slot.be._BASE_URL + 'free_spin',
          data: {
            data_ : JSON.stringify({"token":"5050a05asd","N":30,"free_spin":id})//JSON.stringify({"N" : 30, "BPL": 0.5, "token" : slot.be.token})
          },
          dataType: 'text',
          success: function(fromPHP) {
            slot.be.fromPHP = JSON.parse(fromPHP.split('=')[1]);
            slot.be.check_reponse(slot);
            slot.machine.remove_free_spin_flier();
            slot.machine.update_slot_symbols();
            slot.auto_spin_mode = true 
            slot.auto_spin_num = slot.be.free_spin_num
            slot.controls.update_auto_text();
            slot.controls.auto_btn.inputEnabled = false
            //slot.bonus.data_received();
            //TweenMax.to(self,self.turbo? 0.2 : 1,{onComplete:slot.be.single_stop_reel})
          },
          error : function (xhr, fromPHP, txt) {
            console.log(xhr);
            console.log(fromPHP);
            console.log(txt);
          }
        });
    };

    slot.be.request_free_spin = function(slot,id){
        $.ajax({
          type: "POST",
          url: slot.be._BASE_URL + 'free_spin',
          data: {
            data_ : JSON.stringify({"N" : 30, "BPL": 0.5, "token" : slot.be.token})
          },
          dataType: 'text',
          success: function(fromPHP) {
            slot.be.fromPHP = JSON.parse(fromPHP.split('=')[1]);
            slot.be.check_reponse(slot);
            
          },
          error : function (xhr, fromPHP, txt) {
            console.log(xhr);
            console.log(fromPHP);
            console.log(txt);
          }
        });
    };

    slot.be.update_R = function(){

        if(slot.be.fromPHP.hasOwnProperty("LS")==true){
                slot.be.LS = slot.be.fromPHP.LS.replace(/'/gi,'"')
                slot.be.LS = JSON.parse(slot.be.LS);
                if(slot.be.LS.hasOwnProperty('R')==true){
                  slot.be.R = null; 
                  slot.be.R = slot.be.LS.R.split("|");
                  slot.be.R[0] = slot.be.R[0].split(";") ;  slot.be.R[0].pop() ; slot.be.R[0] = slot.be.R[0].concat(slot.be.R[0]);
                  slot.be.R[1] = slot.be.R[1].split(";") ;  slot.be.R[1].pop() ; slot.be.R[1] = slot.be.R[1].concat(slot.be.R[1]);
                  slot.be.R[2] = slot.be.R[2].split(";") ;  slot.be.R[2].pop() ; slot.be.R[2] = slot.be.R[2].concat(slot.be.R[2]);
                  slot.be.R[3] = slot.be.R[3].split(";") ;  slot.be.R[3].pop() ; slot.be.R[3] = slot.be.R[3].concat(slot.be.R[3]);
                  slot.be.R[4] = slot.be.R[4].split(";") ;  slot.be.R[4].pop() ; slot.be.R[4] = slot.be.R[4].concat(slot.be.R[4]);
              }
            };

    }

    slot.be.reset_response = function(){
    	slot.be.S = []
    	slot.be.WIN = 0
    	slot.be.L = []
    	slot.be.SW = []
    	slot.be.M = "" 
      slot.be.LS = null
    }

    slot.be.check_reponse = function(slot,req){
            //preloader

            if( slot.be.fromPHP.hasOwnProperty('numFR')){
                 slot.be.numFR = parseInt(slot.be.fromPHP.numFR) 
            }

            if( slot.be.fromPHP.hasOwnProperty('response')){
                 slot.be.response = slot.be.fromPHP.response
                 if(slot.be.numFR==1){
                      if(slot.be.response == 0){
                          slot.be.free_spin_num = 20
                      }else
                      if(slot.be.response == 1){
                          slot.be.free_spin_num = 12
                      }else
                      if(slot.be.response == 2){
                          slot.be.free_spin_num = 6
                      }
                 }
            }

            if( slot.be.fromPHP.hasOwnProperty('curFR')){
                 slot.be.curFR = parseInt(slot.be.fromPHP.curFR) 
            }

            if( slot.be.fromPHP.hasOwnProperty('XB')){
                 slot.be.XB = parseInt(slot.be.fromPHP.XB) 
            }

            if( slot.be.fromPHP.hasOwnProperty('NB')){
                 slot.be.NB = parseInt(slot.be.fromPHP.NB) 
            }

            if( slot.be.fromPHP.hasOwnProperty('S')){
                 slot.be.S = slot.be.fromPHP.S.split("|")
            }

            if( slot.be.fromPHP.hasOwnProperty('WIN') ){
                 slot.be.WIN = parseInt(slot.be.fromPHP.WIN)
            }

            if( slot.be.fromPHP.hasOwnProperty('C')){
                 slot.be.C = slot.be.fromPHP.C
            }

            if( slot.be.fromPHP.hasOwnProperty('L')){
                 slot.be.L = slot.be.fromPHP.L
                 slot.be.L = slot.be.L.split("|")
            }

            if( slot.be.fromPHP.hasOwnProperty('M')){
                 slot.be.M = slot.be.fromPHP.M
            }

            if( slot.be.fromPHP.hasOwnProperty('fWin')){
                 slot.be.fWin = parseInt(slot.be.fromPHP.fWin)
            }

            if( slot.be.fromPHP.hasOwnProperty('P')){
                 slot.be.P = slot.be.fromPHP.P.split('|');
            }

            if(slot.be.fromPHP.hasOwnProperty('SW')){
              slot.be.SW = slot.be.fromPHP.SW.split(';');
              slot.be.fast_spin_free = 1
            };

            if(slot.be.fromPHP.hasOwnProperty("LS")){
                slot.be.LS = slot.be.fromPHP.LS.replace(/'/gi,'"')
                slot.be.LS = JSON.parse(slot.be.LS);
                trace('have LS')
            }

            if(slot.be.fromPHP.hasOwnProperty('R')){
                slot.be.R = null; 
                slot.be.R = slot.be.fromPHP.R.split("|");
                slot.be.R[0] = slot.be.R[0].split(";") ;  slot.be.R[0].pop() ; slot.be.R[0] = slot.be.R[0].concat(slot.be.R[0]);
                slot.be.R[1] = slot.be.R[1].split(";") ;  slot.be.R[1].pop() ; slot.be.R[1] = slot.be.R[1].concat(slot.be.R[1]);
                slot.be.R[2] = slot.be.R[2].split(";") ;  slot.be.R[2].pop() ; slot.be.R[2] = slot.be.R[2].concat(slot.be.R[2]);
                slot.be.R[3] = slot.be.R[3].split(";") ;  slot.be.R[3].pop() ; slot.be.R[3] = slot.be.R[3].concat(slot.be.R[3]);
                slot.be.R[4] = slot.be.R[4].split(";") ;  slot.be.R[4].pop() ; slot.be.R[4] = slot.be.R[4].concat(slot.be.R[4]);
            };


            //LAST FREE SPIN
    }


}